# -*- coding: utf-8 -*-
"""

Paper: "Computational Methods for Predicting and Understanding Food Judgment"

Main Analysis

Outline:

[1] Data Cleaning: 
    Read in participant data for each study and condition:
    control_1A, control_2A, control_2B, control_2C = General Population sample [food name only]
    exp_1B = Study 1 Experimental Condition:(Registered Dietitian) sample [food name only]
    exp_1C = Study 1 Second Experimental Condition: Food Name + Food Images
    exp_2A = Study 2A Experimental Condition: Food Name + Calorie Content per 100g
    exp_2B = Study 2B Experimental Condition: Food Name + Front of Pack Key Nutrient Content per 100g (FoP)
    exp_2C = Study 2C Experimental Condition: Food Name + Traffic Light Coloured Key Nutrient Content per 100g (TLL)
    Generate aggregated healthiness ratings for each food item per condition

[2] Predicted Healthiness Ratings obtained using the Vector Representation Model [word vectors] in each condition
    + correlation with actual (aggregated) participant ratings (pearson r and r2_score)

[3] Predicted Healthiness Ratings obtained using the Nutrient Model ["energy","totfat","satfat","totsug","salt","sodium","protein","totfatc","satfatc","totsugc","saltc"] in each condition
    + correlation with actual (aggregated) participant ratings (pearson r and r2_score)

[4] Predicted Healthiness Ratings obtained using the Combined Model [Vector Representation Model + Nutrient Model] in each condition
    + correlation with actual (aggregated) participant ratings (pearson r and r2_score)

[5] Predicted Differences between conditions of each study using the Vector Representation Model and the Combined Model (pearson r and r2_score)

[6] Predict healthiness ratings for common words that are not stimuli words taken from COCA dictionary (Word Clouds)
    + word clouds showing the 50 words with the highest/lowest healthiness ratings 

[7] Predict healthiness ratings for other foods taken from the USDA Database and McCance and Widdowsons Composition of Foods Integrated Database
    [A list of all unique foods from these databases is found in the Supplementary Materials] 
    
"""
    
'''load packages '''

import csv
import numpy as np
import gensim.models as models
import pandas as pd
from scipy.stats.stats import pearsonr
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import Normalizer
from sklearn.model_selection import LeaveOneOut
from pattern.text.en import singularize
from sklearn.metrics import r2_score


# download, save and read in Word2Vec [will take approx 10 minutes]
word2vec = models.KeyedVectors.load_word2vec_format(r'Path where word2vec is downloaded to\GoogleNews-vectors-negative300.bin.gz', binary=True)



#######################################################################################
################################### 1. Data Cleaning ##################################
#######################################################################################


'''load data for each study and split into control and experimental condition'''

control_1A = pd.read_csv(r'Path where the CSV file is stored/1A_Ratings.csv')
exp_1B=pd.read_csv(r'Path where the CSV file is stored/1B_Ratings(RDs).csv')
exp_1C=pd.read_csv(r'Path where the CSV file is stored/1C_Ratings(Pics).csv')


study_2A=pd.read_csv(r'Path where the CSV file is stored/2A_Ratings(Kcal).csv')
control_2A=study_2A[study_2A['condition']=='Control']
exp_2A=study_2A[study_2A['condition']=='Calories']

study_2B=pd.read_csv(r'Path where the CSV file is stored/2B_Ratings(FoP).csv')
control_2B=study_2B[study_2B['condition']=='Control']
exp_2B=study_2B[study_2B['condition']=='FoP']

study_2C=pd.read_csv(r'Path where the CSV file is stored/2C_Ratings(TLL).csv')
control_2C=study_2C[study_2C['condition']=='Control']
exp_2C=study_2C[study_2C['condition']=='TLL']


'''generate group level data for each condition'''

control_1A=control_1A.groupby(['food_name']).mean()
exp_1B=exp_1B.groupby(['food_name']).mean()
exp_1C=exp_1C.groupby(['food_name']).mean()

control_2A=control_2A.groupby(['food_name']).mean()
exp_2A=exp_2A.groupby(['food_name']).mean()

control_2B=control_2B.groupby(['food_name']).mean()
exp_2B=exp_2B.groupby(['food_name']).mean()

control_2C=control_2C.groupby(['food_name']).mean()
exp_2C=exp_2C.groupby(['food_name']).mean()



##################################################################
################ 2. Vector Representation Model ##################
##################################################################


'''get word vectors for food items (x in model)'''
food=control_1A.index.values
x=word2vec[food[0]]
for item in food[1:len(food)]:
    x=np.vstack((x,word2vec[item]))
'''normalize word vectors'''
nx=Normalizer().fit(x).transform(x)



'''Leave-one-out cross-validation (LOOCV) for Vector Representation Model'''

'''change y to switch condition'''
y=control_1A['rating']          #looy_ridge_con_1A_VRM
#y=exp_1B['rating']              #looy_ridge_exp_1B_VRM
#y=exp_1C['rating']              #looy_ridge_exp_1C_VRM
#y=control_2A['rating']          #looy_ridge_con_2A_VRM
#y=exp_2A['rating']              #looy_ridge_exp_2A_VRM
#y=control_2B['rating']          #looy_ridge_con_2B_VRM
#y=exp_2B['rating']              #looy_ridge_exp_2B_VRM
#y=control_2C['rating']          #looy_ridge_con_2C_VRM
#y=exp_2C['rating']              #looy_ridge_exp_2C_VRM


'''replace "looy_ridge_[]" with the corresponding variable name for the condition '''
looy_ridge_con_1A_VRM=np.zeros(172)  #change condition accordingly
for train_index, test_index in LeaveOneOut().split(nx):
    X_train, X_test = nx[train_index], nx[test_index]
    y_train, y_test = y[train_index], y[test_index]
    looy_ridge_con_1A_VRM[test_index]=Ridge(alpha=1).fit(X_train,y_train).predict(X_test)    #change condition accordingly
    
'''remove # to calculate the correlation coefficient for that condition (and check it against these previously calculated & reported coefficients)''' 

'''pearsonr'''
loocv_con_1A_VRM=pearsonr(y,looy_ridge_con_1A_VRM)    # (0.883225013204967, 8.525504361242698e-58) for Study 1A Control
#loocv_exp_1B_VRM=pearsonr(y,looy_ridge_exp_1B_VRM)    # (0.8414305590631039, 2.6114691166509986e-47) for Study 1B Experimental (Experts)
#loocv_exp_1C_VRM=pearsonr(y,looy_ridge_exp_1C_VRM)    # (0.8766641596371573, 6.651726202312508e-56) for Study 1C Experimental (Food Images)
#loocv_con_2A_VRM=pearsonr(y,looy_ridge_con_2A_VRM)    # (0.8877411247483622, 3.6389806509262976e-59) for Study 2A Control 
#loocv_exp_2A_VRM=pearsonr(y,looy_ridge_exp_2A_VRM)    # (0.8835752967035017, 6.706835472051238e-58) for Study 2A Experimental (Calories)
#loocv_con_2B_VRM=pearsonr(y,looy_ridge_con_2B_VRM)    # (0.8846084021826481, 3.290245525330838e-58) for Study 2B Control 
#loocv_exp_2B_VRM=pearsonr(y,looy_ridge_exp_2B_VRM)    # (0.8739484959363176, 3.756614728715505e-55) for Study 2B Experimental (FoP labelling)
#loocv_con_2C_VRM=pearsonr(y,looy_ridge_con_2C_VRM)    # (0.8841307132945142, 4.577242173046673e-58) for Study 2C Control
#loocv_exp_2C_VRM=pearsonr(y,looy_ridge_exp_2C_VRM)    # (0.8211530032872557, 2.8895408876400404e-43) for Study 2C Experimental (TLL labelling)

''' r2 '''
loocv_con_1A_VRM=r2_score(y,looy_ridge_con_1A_VRM)    # 0.7586791031183436 for Study 1A Control
#loocv_exp_1B_VRM=r2_score(y,looy_ridge_exp_1B_VRM)    # 0.6881519051040332 for Study 1B Experimental (Experts)
#loocv_exp_1C_VRM=r2_score(y,looy_ridge_exp_1C_VRM)    # 0.7497306848888494 for Study 1C Experimental (Food Images)
#loocv_con_2A_VRM=r2_score(y,looy_ridge_con_2A_VRM)    # 0.7670270463498385 for Study 2A Control 
#loocv_exp_2A_VRM=r2_score(y,looy_ridge_exp_2A_VRM)    # 0.7574224395967817 for Study 2A Experimental (Calories)
#loocv_con_2B_VRM=r2_score(y,looy_ridge_con_2B_VRM)    # 0.7611868241436588 Study 2B Control 
#loocv_exp_2B_VRM=r2_score(y,looy_ridge_exp_2B_VRM)    # 0.7398733450004943 for Study 2B Experimental (FoP labelling)
#loocv_con_2C_VRM=r2_score(y,looy_ridge_con_2C_VRM)    # 0.7593567477056775 for Study 2C Control
#loocv_exp_2C_VRM=r2_score(y,looy_ridge_exp_2C_VRM)    # 0.6518809797700149 for Study 2C Experimental (TLL labelling)



#############################################################
################ 3. Nutrient Content Model ##################
#############################################################


'''LOOCV using calories+nutrients+TLL change y accordingly'''
nutrient=pd.read_csv(r'Path where the CSV file is stored/nutrients info.csv')    
X = nutrient[["energy","totfat","satfat","totsug","salt","sodium","protein","totfatc","satfatc","totsugc","saltc"]]
X=X.values

'''change y to switch condition'''
y=control_1A['rating']      #looy_linear_con_1A_NM
#y=exp_1B['rating']          #looy_linear_exp_1B_NM
#y=exp_1C['rating']         #looy_linear_exp_1C_NM
#y=control_2A['rating']      #looy_linear_con_2A_NM
#y=exp_2A['rating']          #looy_linear_exp_2A_NM
#y=control_2B['rating']      #looy_linear_con_2B_NM
#y=exp_2B['rating']          #looy_linear_exp_2B_NM
#y=control_2C['rating']      #looy_linear_con_2C_NM
#y=exp_2C['rating']          #looy_linear_exp_2C_NM


'''replace "looy_linear[]" with the corresponding variable name for the condition '''
looy_linear_con_1A_NM=np.zeros(172)  
for train_index, test_index in LeaveOneOut().split(X):
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]
    looy_linear_con_1A_NM[test_index]=LinearRegression().fit(X_train, y_train).predict(X_test)   #change condition accordingly
    
'''remove # to calculate the correlation coefficient for that condition (and check it against these previously calculated & reported coefficients)'''    

'''pearsonr'''    
loocv_linear_con_1A_NM=pearsonr(y,looy_linear_con_1A_NM)     # (0.5985119166629075, 4.2915761309996545e-18) for Study 1A Control    
#loocv_linear_exp_1B_NM=pearsonr(y,looy_linear_exp_1B_NM)     # (0.6291714430135269, 2.401219876734538e-20) for Study 1B Experimental (Experts)
#loocv_linear_exp_1C_NM=pearsonr(y,looy_linear_exp_1C_NM)     # (0.6135694937962815, 3.6070135705519063e-19) for Study 1C Experimental (Food Images)
#loocv_linear_con_2A_NM=pearsonr(y,looy_linear_con_2A_NM)     # (0.581725013098341, 5.847208923311654e-17)) for Study 2A Control 
#loocv_linear_exp_2A_NM=pearsonr(y,looy_linear_exp_2A_NM)     # (0.6747234957843855, 3.393310062152062e-24) for Study 2A Experimental (Calories) 
#loocv_linear_con_2B_NM=pearsonr(y,looy_linear_con_2B_NM)     # (0.5880092082685104, 2.238633038961988e-17) Study 2B Control
#loocv_linear_exp_2B_NM=pearsonr(y,looy_linear_exp_2B_NM)     # (0.7316377424796391, 4.263696027215696e-30) for Study 2B Experimental (FoP labelling)
#loocv_linear_con_2C_NM=pearsonr(y,looy_linear_con_2C_NM)     # (0.6027082591888244, 2.180675053286752e-18) for Study 2C Control    
#loocv_linear_exp_2C_NM=pearsonr(y,looy_linear_exp_2C_NM)     # (0.8799420821870825, 7.787326857708422e-57)for Study 2C Experimental (TLL labelling)


''' r2 '''
loocv_linear_con_1A_NM=r2_score(y,looy_linear_con_1A_NM)     # 0.3524131997914346 for Study 1A Control    
#loocv_linear_exp_1B_NM=r2_score(y,looy_linear_exp_1B_NM)     # 0.3908910775062625 for Study 1B Experimental (Experts)
#loocv_linear_exp_1C_NM=r2_score(y,looy_linear_exp_1C_NM)   # 0.367820488958174for Study 1C Experimental (Food Images)
#loocv_linear_con_2A_NM=r2_score(y,looy_linear_con_2A_NM)     # 0.33160002981875103 for Study 2A Control 
#loocv_linear_exp_2A_NM=r2_score(y,looy_linear_exp_2A_NM)     # 0.45196302258156995 for Study 2A Experimental (Calories) 
#loocv_linear_con_2B_NM=r2_score(y,looy_linear_con_2B_NM)     # 0.33921126210407804 Study 2B Control
#loocv_linear_exp_2B_NM=r2_score(y,looy_linear_exp_2B_NM)     # 0.5331753928138292 for Study 2B Experimental (FoP labelling)
#loocv_linear_con_2C_NM=r2_score(y,looy_linear_con_2C_NM)     # 0.35726775524058463 for Study 2C Control    
#loocv_linear_exp_2C_NM=r2_score(y,looy_linear_exp_2C_NM)     # 0.7739454520907612 for Study 2C Experimental (TLL labelling)



#####################################################
################ 4. Combined Model ##################
#####################################################


'''LOOCV using combined Vector Representation and Nutrient Model predictors'''
combination = np.hstack((nx,X))
    

'''change y to switch condition'''
y=control_1A['rating']          #looy_ridge_con_1A_CM
#y=exp_1B['rating']              #looy_ridge_exp_1B_CM
#y=exp_1C['rating']             #looy_ridge_exp_1C_CM
#y=control_2A['rating']          #looy_ridge_con_2A_CM
#y=exp_2A['rating']              #looy_ridge_exp_2A_CM
#y=control_2B['rating']          #looy_ridge_con_2B_CM
#y=exp_2B['rating']              #looy_ridge_exp_2B_CM
#y=control_2C['rating']          #looy_ridge_con_2C_CM
#y=exp_2C['rating']              #looy_ridge_exp_2C_CM    
    
    
'''replace "looy_ridge_[]" with the corresponding variable name for the condition '''
looy_ridge_con_1A_CM=np.zeros(172)   #change condition accordingly
for train_index, test_index in LeaveOneOut().split(combination):
    X_train, X_test = combination[train_index], combination[test_index]
    y_train, y_test = y[train_index], y[test_index]
    looy_ridge_con_1A_CM[test_index]=Ridge(alpha=1).fit(X_train,y_train).predict(X_test)     #change condition accordingly
 
'''remove # to calculate the correlation coefficient for that condition (and check it against these previously calculated & reported coefficients)'''      

'''pearsonr''' 
#loocv_ridge_con_1A_CM=pearsonr(y,looy_ridge_con_1A_CM)   # (0.8774959634432027, 3.8822253194410025e-56)  for Study 1A Control
#loocv_ridge_exp_1B_CM=pearsonr(y,looy_ridge_exp_1B_CM)   # (0.8679106540065759, 1.5339432423565443e-53) for Study 1B Experimental (Experts)
#loocv_ridge_exp_1C_CM=pearsonr(y,looy_ridge_exp_1C_CM) # (0.8760406828369816, 9.933725518233502e-56)(0.8760406828369816, 9.933725518233502e-56) for Study 1C Experimental (Food Images)
#loocv_ridge_con_2A_CM=pearsonr(y,looy_ridge_con_2A_CM)   # (0.8813123818053406, 3.117899178726674e-57) for Study 2A Control
#loocv_ridge_exp_2A_CM=pearsonr(y,looy_ridge_exp_2A_CM)   # (0.9008017739678917, 1.7511580020771214e-63) for Study 2A Experimental (Calories) 
#loocv_ridge_con_2B_CM=pearsonr(y,looy_ridge_con_2B_CM)   # (0.880242904401749, 6.37583069456948e-57) for Study 2B Control
#loocv_ridge_exp_2B_CM=pearsonr(y,looy_ridge_exp_2B_CM)   # (0.9091786790659108, 1.3957986002255692e-66) for Study 2B Experimental (FoP labelling)
#loocv_ridge_con_2C_CM=pearsonr(y,looy_ridge_con_2C_CM)   # (0.8815162788767443, 2.7182647028383903e-57) for Study 2C Control
#loocv_ridge_exp_2C_CM=pearsonr(y,looy_ridge_exp_2C_CM)   # (0.9546365067381543, 2.3262466121520465e-91) for Study 2C Experimental (TLL labelling)


''' r2 ''' 
loocv_ridge_con_1A_CM=r2_score(y,looy_ridge_con_1A_CM)   # 0.7664076873365299 for Study 1A Control
#loocv_ridge_exp_1B_CM=r2_score(y,looy_ridge_exp_1B_CM)   # 0.7513700468249126 for Study 1B Experimental (Experts)
#loocv_ridge_exp_1C_CM=r2_score(y,looy_ridge_exp_1C_CM) # 0.7648270621319186 for Study 1C Experimental (Food Images)
#loocv_ridge_con_2A_CM=r2_score(y,looy_ridge_con_2A_CM)   # 0.7726059386905151for Study 2A Control
#loocv_ridge_exp_2A_CM=r2_score(y,looy_ridge_exp_2A_CM)   # 0.808923492856136 for Study 2A Experimental (Calories) 
#loocv_ridge_con_2B_CM=r2_score(y,looy_ridge_con_2B_CM)   # 0.7707751582346123 for Study 2B Control
#loocv_ridge_exp_2B_CM=r2_score(y,looy_ridge_exp_2B_CM)   # 0.8254810742760434 for Study 2B Experimental (FoP labelling)
#loocv_ridge_con_2C_CM=r2_score(y,looy_ridge_con_2C_CM)   # 0.773620469865769 for Study 2C Control
#loocv_ridge_exp_2C_CM=r2_score(y,looy_ridge_exp_2C_CM)   # 0.9111671136077616 for Study 2C Experimental (TLL labelling)


###################################################################################
################# 5. Differences Between Conditions of Each Study #################
###################################################################################


    
'''Predicting Differences Between Conditions of Each Study using the Vector Representation Model '''

'''change y to switch condition'''
y=exp_2A['rating']-control_2A['rating']       #looy_ridge_diff_2A_VRM
#y=exp_2B['rating']-control_2B['rating']      #looy_ridge_diff_2B_VRM
#y=exp_2C['rating']-control_2C['rating']      #looy_ridge_diff_2C_VRM


'''replace "looy_ridge_[]" with the corresponding variable name for the condition '''
looy_ridge_diff_2A_VRM=np.zeros(172)     #change condition accordingly
for train_index, test_index in LeaveOneOut().split(nx):
   X_train, X_test = nx[train_index], nx[test_index]
   y_train, y_test = y[train_index], y[test_index]
   looy_ridge_diff_2A_VRM[test_index]=Ridge(alpha=1).fit(X_train,y_train).predict(X_test)    #change condition accordingly


'''remove # to calculate the correlation coefficient for that condition (and check it against these previously calculated & reported coefficients)''' 

'''pearsonr'''
loocv_ridge_diff_2A_VRM=pearsonr(y,looy_ridge_diff_2A_VRM)   # (0.5856256700040756, 3.229937924712002e-17) for Study 2A
#loocv_ridge_diff_2B_VRM=pearsonr(y,looy_ridge_diff_2B_VRM)   # (0.43441270556223827, 2.6163135045584243e-09) for Study 2B
#loocv_ridge_diff_2C_VRM=pearsonr(y,looy_ridge_diff_2C_VRM)   #  (0.5418718415773284, 1.6379475912235424e-14) for Study 2C

''' r2 ''' 
loocv_ridge_diff_2A_VRM=r2_score(y,looy_ridge_diff_2A_VRM)   # 0.3356411890661195 for Study 2A
#loocv_ridge_diff_2B_VRM=r2_score(y,looy_ridge_diff_2B_VRM)   # 0.1879627286016612 for Study 2B
#loocv_ridge_diff_2C_VRM=r2_score(y,looy_ridge_diff_2C_VRM)   # 0.2853875549112461 for Study 2C

        

'''Predicting Differences Between Conditions of Each Study using the Combined Model '''

'''change y to switch condition'''
y=exp_2A['rating']-control_2A['rating']      #looy_ridge_diff_2A_CM
#y=exp_2B['rating']-control_2B['rating']      #looy_ridge_diff_2B_CM
#y=exp_2C['rating']-control_2C['rating']      #looy_ridge_diff_2C_CM


'''replace "looy_ridge_[]" with the corresponding variable name for the condition '''
looy_ridge_diff_2A_CM=np.zeros(172)  #change condition accordingly
for train_index, test_index in LeaveOneOut().split(combination):
    X_train, X_test = combination[train_index], combination[test_index]
    y_train, y_test = y[train_index], y[test_index]
    looy_ridge_diff_2A_CM[test_index]=Ridge(alpha=1).fit(X_train,y_train).predict(X_test)    #change condition accordingly


'''remove # to calculate the correlation coefficient for that condition (and check it against these previously calculated & reported coefficients)''' 
loocv_ridge_diff_2A_CM=pearsonr(y,looy_ridge_diff_2A_CM)   # (0.6767033021971349, 2.2265134709463063e-24) for Study 2A
#loocv_ridge_diff_2B_CM=pearsonr(y,looy_ridge_diff_2B_CM)   # (0.7410369393654643, 3.2216713846438523e-31) for Study 2B
#loocv_ridge_diff_2C_CM=pearsonr(y,looy_ridge_diff_2C_CM)   # (0.8352200682851403, 5.1706834822180375e-46) for Study 2C
    
loocv_ridge_diff_2A_CM=r2_score(y,looy_ridge_diff_2A_CM)   # 0.4571920678520084 for Study 2A
#loocv_ridge_diff_2B_CM=r2_score(y,looy_ridge_diff_2B_CM)   # 0.5477770775102897 for Study 2B
#loocv_ridge_diff_2C_CM=r2_score(y,looy_ridge_diff_2C_CM)   # 0.6946891618900886 for Study 2C



#################################################################################################
############ 6. Predicting Healthiness Ratings of "other" common words (WORD CLOUDS) ############ 
#################################################################################################


''' get normalized word vectors for common words (that are not stimuli words) in COCA dictionary'''
corpus=[item.split('_') for item in food]
vocabs=[]
for item in corpus:
    vocabs=vocabs+[item[i] for i in range(0,len(item))]
vocab = [singularize(plural) for plural in vocabs] # change plurals to singulars 
with open(r'Path where the CSV file is stored/COCA dictionary.csv') as a:
    f=csv.reader(a,delimiter=',')
    word=[]
    for row in f:
        if row[0] in word2vec and row[0] not in vocab:
            word.append(row[0])                   
base=word2vec[word[0]]
for item in word[1:len(word)]:
    base=np.vstack((base,word2vec[item])) 
nbase=Normalizer().fit(base).transform(base)


'''predict ratings for COCA words'''
y=control_1A['rating']         
#y=exp_1B['rating']
#y=exp_1C['rating']
#y=control_2A['rating']         
#y=exp_2A['rating']    
#y=control_2B['rating']         
#y=exp_2B['rating']    
#y=control_2C['rating']         
#y=exp_2C['rating']    

'''generate table with the healthiness ratings of all COCA words '''
pseudo=pd.DataFrame(index=word,columns=['control_1A','exp_1B', 'exp_1C', 'control_2A','exp_2A', 'control_2B','exp_2B', 'control_2C','exp_2C'])
pseudo['control_1A']=Ridge(alpha=1).fit(nx,y).predict(nbase) #change condition accordingly


'''generate word clouds for the words with the highest/lowest healthiness ratings'''
freq={}
for i in range(len(word)):
    freq[word[i]]=pseudo['control_1A'][i] # use -pseudo[condition_name] to see words with lowest ratings, change condition accordingly
wordcloud = WordCloud(width=1350,height=750,max_words=50,background_color='white',
                      relative_scaling=1, normalize_plurals=False).generate_from_frequencies(freq) 
# set max_words to the number of words in your wordcloud
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
#plt.savefig(fname='1a lay high 50.png') # rename the file accordingly
plt.show()



############################################################################
############ 7. Predicting Healthiness Ratings of "other" foods ############
############################################################################


'''get normalized word vectors for other foods in the USDA database'''
corpus=[item.split('_') for item in food]
vocabs=[]
for item in corpus:
    vocabs=vocabs+[item[i] for i in range(0,len(item))]
vocab = [singularize(plural) for plural in vocabs] # change plurals to singulars 
with open(r'Path where the CSV file is stored/USDA_AllFoods_Python.csv') as a:
    f=csv.reader(a,delimiter=',')
    word=[]
    for row in f:
        if row[0] in word2vec and row[0] not in vocab:
            word.append(row[0])                   
base=word2vec[word[0]]
for item in word[1:len(word)]:
    base=np.vstack((base,word2vec[item])) 
nbase=Normalizer().fit(base).transform(base)



'''predict ratings for other foods in the USDA database'''
y=control_1A['rating']         
#y=exp_1B['rating']
#y=exp_1C['rating']
#y=control_2A['rating']         
#y=exp_2A['rating']    
#y=control_2B['rating']         
#y=exp_2B['rating']    
#y=control_2C['rating']         
#y=exp_2C['rating']    

other_USDA=pd.DataFrame(index=word,columns=['control_1A','exp_1B', 'exp_1C', 'control_2A','exp_2A', 'control_2B','exp_2B', 'control_2C','exp_2C'])
other_USDA['control_1A']=Ridge(alpha=1).fit(nx,y).predict(nbase)    #change condition accordingly



'''get normalized word vectors for other foods in the McCance and Widdowsons Composition of Foods Integrated Database (CoFID)2019'''

corpus=[item.split('_') for item in food]
vocabs=[]
for item in corpus:
    vocabs=vocabs+[item[i] for i in range(0,len(item))]
vocab = [singularize(plural) for plural in vocabs] # change plurals to singulars 
with open(r'Path where the CSV file is stored/CoFID_AllFoods_Python.csv') as a:
    f=csv.reader(a,delimiter=',')
    word=[]
    for row in f:
        if row[0] in word2vec and row[0] not in vocab:
            word.append(row[0])                   
base=word2vec[word[0]]
for item in word[1:len(word)]:
    base=np.vstack((base,word2vec[item])) 
nbase=Normalizer().fit(base).transform(base)


'''predict ratings for other foods in the CoFID database'''
y=control_1A['rating']         
#y=exp_1B['rating']
#y=exp_1C['rating']
#y=control_2A['rating']         
#y=exp_2A['rating']    
#y=control_2B['rating']         
#y=exp_2B['rating']    
#y=control_2C['rating']         
#y=exp_2C['rating']    

other_CoFID=pd.DataFrame(index=word,columns=['control_1A','exp_1B', 'exp_1C', 'control_2A','exp_2A', 'control_2B','exp_2B', 'control_2C','exp_2C'])
other_CoFID['control_1A']=Ridge(alpha=1).fit(nx,y).predict(nbase) #change condition accordingly






