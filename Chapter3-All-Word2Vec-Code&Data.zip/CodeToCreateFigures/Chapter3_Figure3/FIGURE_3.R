
library(data.table)
library(ggplot2)
library(ggrepel)
library(dplyr)


library(signs) #replaces hyphen (U+002D)  in plots with true minus sign (U+2212)  

dt <- fread("PCAR.csv",
            stringsAsFactors = FALSE, header = TRUE, data.table=getOption("datatable.fread.datatable", TRUE))
dt <- setnames(dt, "food", "food_name")
dt$food_name <- gsub(" ", "_", dt$food_name)
df <- dt

#read in nutrient info for food category 
nutrients <- fread("nutrients info.csv",
                   stringsAsFactors = FALSE, header = TRUE)[, c("food_name", "food_cat")]
nutrients$food_cat <- as.factor(nutrients$food_cat)


levels <- c("Vegetables and Vegetable Products", "Fruits and Fruit Juices", "Nut and Seed Products", "Legumes and Legume Products", "Cereal Grains and Pasta", "Breakfast Cereals", "Fats and Oils", "Dairy and Egg Products", "Baked Products", "Beverages", "Sweets", "Snacks", "Finfish and Shellfish Products", "Poultry Products", "Sausages and Luncheon Meats", "Pork Products", "Lamb, Veal, and Game Products", "Beef Products", "Soups, Sauces, and Gravies", "Meals, Entrees, and Side Dishes")
nutrients$food_cat <- factor(nutrients$food_cat, levels = levels)

#df <- merge(dt, nutrients, by = "food_name")

 

food_labels <- c("cola", "lemonade", "aloe_vera_juice", "margarita", "beef_sirloin", 
                 "cream_cheese", "scrambled_eggs", "kit_kat", "soft_pretzels", "eggnog",
                 "flaxseed_oil", "roasted_peanuts", "cashew_nuts", "waffle","cinnamon_bun", 
                 "dark_chocolate", "shortbread_cookie", "lemon_meringue_pie", "rice_pudding", "baked_beans", 
                 "pancakes", "pecan_pie", "sponge_cake", "french_toast", "pepperoni_pizza", 
                 "dumpling", "mango", "fig", "apple", "corn", 
                 "lettuce", "cucumber", "beets", "olives", "avocado", 
                 "kale", "asparagus", "brussels_sprouts", "broccoli", "baked_sweet_potato",
                 "cantaloupe", "coconut_milk", "bacon", "fajita", "chicken_curry", 
                 "pad_thai", "onion_rings", "chicken_enchilada", "ravioli", "roasted_turkey"    
                 )                       

food_labels <- as.data.table(food_labels)
food_labels <- setnames(food_labels, "food_labels", "food_name")



#convert the row names to the food names, replacing spaces between words with an underscore
row.names(df) <- paste(df$food_name, row.names(df), sep = "-")
row.names(df) <- gsub("(.*)-.*","\\1", row.names(df))
row.names(df) <- gsub(" ", "_", row.names(df))

#remove the food name column because we can only have numerical data in the columns
df$food_name <- NULL

df_pca <- prcomp(df)

df_out <- as.data.frame(df_pca$x)





#bind PCA dimensions with nutrient data to use the food categories as a grouping variable in the data viz
df <- cbind(df, nutrients)


#create a new dataset with just the labels of interest
food_labels <- df %>%
  inner_join(food_labels, by = "food_name")
# label_df <- subset(dt, food_name %in% label)
# 
# dt$label <- label_df
# 




p <- ggplot(df, aes(pca1, pca2, colour = food_cat)) + 
  geom_point(size = 1) +
  labs(colour= "Food Category") +
  geom_hline(yintercept = 0, linetype = "dashed", colour = "darkgrey") + 
  geom_vline(xintercept = 0, linetype = "dashed", colour = "darkgrey") +
#  xlim(-0.6,0.6) + ylim(-0.6,0.6) + 
  ggplot2::scale_y_continuous(limits = c(-0.6, 0.6), breaks = seq(-0.6, 0.6, by = 0.3), labels = signs_format(accuracy = 0.1)) +                                #sets intervals of y-axis to every 100
  ggplot2::scale_x_continuous(limits = c(-0.6, 0.6), breaks = seq(-0.6, 0.6, by = 0.3), labels = signs_format(accuracy = 0.1)) +                                #sets intervals of x-axis to every 100#sets intervals of x-axis to every 100
  
  labs(x = "Component 1", y = "Component 2") +
  theme_classic() +
  theme(axis.line = element_blank(), legend.position = "top") +
  theme(axis.text.x = element_text(size = 9, family = "sans"), axis.title.x = element_text(size = 10)) +
  theme(axis.text.y = element_text(size = 9, family = "sans"), axis.title.y = element_text(size = 10)) +
  theme(legend.text = element_text(size = 9, family = "sans"), legend.title = element_text(size = 9)) 


p <- p + geom_text_repel(data = food_labels, aes(label=food_name),
                         #hjust=-0.6, vjust=0.4, 
                         size = 9/ .pt, fontface = "plain", family = "sans", show.legend = F, 
                        # box.padding = 0.25,
                        # point.padding = 0.5,
                         max.overlaps = Inf, segment.color = 'lightgrey' 
)



ggsave("Figure3.pdf", dpi = 300, width = 29.7, height = 21, units = "cm")
