# Code Overview -----------------------------------------------------------

# R Code to reproduce Figure 2: LOOCV results for the Vector Representation Model and Nutrient Model used in thesis: "Understanding individual food healthiness perceptions using a computational approach"
# Written by Natasha Gandhi
# email: n.gandhi.1@warwick.ac.uk
# last update: 2019 10 07 

# Outline:

# [1] Load Data and Cleanup:
## control_1 = Study 1A (Food Name only): N Model, VR Model and C Model
## exp_1 = Study 1B (Food Name only: Dietitians): N Model, VR Model and C Model 
## control_2 = Study 2 (Food Name only): N Model, VR Model and C Model 
## exp_2 = Study 2 (Calorie Information): N Model, VR Model and C Model
## control_3 = Study 3 (Food Name only): N Model, VR Model and C Model 
## exp_3 = Study 3 (Front of Package Labelling Information): N Model, VR Model and C Model
## control_4 = Study 3 (Food Name only): N Model, VR Model and C Model
## exp_4 = Study 4 (Traffic Light Labelling Colour Information): N Model, VR Model and C Model 

# [2] Obtain R-squared values:
## lm_eqn = function to format R-squared (single value) for the dataset
## lm_eqns = function to apply R-squared to each of the computational (VRM, NM and CM) models
## r2_[datasetname] = saved r-squared values for each computational model

# [3] Scatterplots for each condition:
## custom_ggplot_function = function to create scatterplot for each condition
## sp_[datasetname] = saved scatterplot

# [4] Scatterplots for each study:
## Figure_1_function = function to combine plots from each condition per study and create Figure:
## Study[number] = saved figure for each study 



# Packages needed ---------------------------------------------------------

# Data Cleaning 
library(data.table)
library(dplyr)

# Data Visualisation
library(ggplot2)
library(ggpubr) #publication ready plots
library(cowplot) #combine figures 
library(viridis)

library(signs) #replaces hyphen (U+002D)  in plots with true minus sign (U+2212)  

# Load Data and Cleanup ------------------------------------------------------


## Read in data for Study 1 (control vs experts)
control_2A <- fread("Control_2A_AllModels.csv", stringsAsFactors = FALSE, na.strings = "")
exp_2A <- fread("Exp_2A_AllModels.csv", stringsAsFactors = FALSE, na.strings = "")

control_2B <- fread("Control_2B_AllModels.csv", stringsAsFactors = FALSE, na.strings = "")
exp_2B <- fread("Exp_2B_AllModels.csv", stringsAsFactors = FALSE, na.strings = "")

control_2C <- fread("Control_2C_AllModels.csv", stringsAsFactors = FALSE, na.strings = "")
exp_2C <- fread("Exp_2C_AllModels.csv", stringsAsFactors = FALSE, na.strings = "")


# create function to manually set order of the computational models in the plot 
#(Vector Representation Model = left, Nutrient Model = right) 
neworder <- function(df){
  neworder <- c("Nutrient Model","Vector Representation Model", "Combined Model");
  no = arrange(mutate(df, model = factor(model, levels = neworder)), model)
}

#apply function to each dataset
control_2A  <- neworder(control_2A)
exp_2A  <- neworder(exp_2A)


control_2B  <- neworder(control_2B)
exp_2B  <- neworder(exp_2B)


control_2C  <- neworder(control_2C)
exp_2C  <- neworder(exp_2C)




r2_2A_con <- data.frame(
  x = -60, y = 95,
  label = c("0.33", "0.77", "0.77"),
  model   = factor(c("Nutrient Model", "Vector Representation Model", "Combined Model"), levels = c("Nutrient Model", "Vector Representation Model", "Combined Model")))#,


r2_2A_exp <- data.frame(
  x = -60, y = 95,
  label = c("0.45", "0.76", "0.81"),
  model   = factor(c("Nutrient Model", "Vector Representation Model", "Combined Model"), levels = c("Nutrient Model", "Vector Representation Model", "Combined Model")))#,




r2_2B_con <- data.frame(
  x = -60, y = 95,
  label = c("0.34", "0.76", "0.77"),
  model   = factor(c("Nutrient Model", "Vector Representation Model", "Combined Model"), levels = c("Nutrient Model", "Vector Representation Model", "Combined Model")))#,


r2_2B_exp <- data.frame(
  x = -60, y = 95,
  label = c("0.53", "0.74", "0.83"),
  model   = factor(c("Nutrient Model", "Vector Representation Model", "Combined Model"), levels = c("Nutrient Model", "Vector Representation Model", "Combined Model")))#,


r2_2C_con <- data.frame(
  x = -60, y = 95,
  label = c("0.36", "0.76", "0.77"),
  model   = factor(c("Nutrient Model", "Vector Representation Model", "Combined Model"), levels = c("Nutrient Model", "Vector Representation Model", "Combined Model")))#,


r2_2C_exp <- data.frame(
  x = -60, y = 95,
  label = c("0.77", "0.65", "0.91"),
  model   = factor(c("Nutrient Model", "Vector Representation Model", "Combined Model"), levels = c("Nutrient Model", "Vector Representation Model", "Combined Model")))#,



# Scatterplots for each condition -----------------------------------------




control_plot = function(df, study, stimulus, r2){
  

  # create function to make a scatterplot for each condition
  sp = ggplot(df, aes(x = actual_rating, y = predicted_rating)) +
    labs(
      x = "Actual Ratings", y = "Predicted Ratings",
      #title = participant_sample, 
      subtitle = c(study, stimulus)) +
    geom_point(aes(color = model), size = 2, alpha = 0.6) +                                         #size of each data point (n = 172 food items)
    geom_smooth(aes(color = model, fill = model),method = "lm", fullrange = TRUE, formula = y ~ x, size = 2.5) +  #r squared line                       #r square value
    facet_wrap(~model, scales = "fixed") +                                                          #separates data for VR and N computational models 
    scale_color_manual(values = c("#21908CFF", "#3B528BFF", "#440154FF")) +   #viridis manual 
    scale_fill_manual(values = c("#21908CFF", "#3B528BFF", "#440154FF")) +                                      #colours used to distinguish between computational models
    theme_pubr(legend = "none") +                                                   #increases font size of x-axis and y-axis labels and removes legend 
    theme(axis.text.x = element_text(size = 10, family = "sans"), axis.title = element_text(size = 12, family = "sans"), axis.line = element_line(colour = "grey", size = 0.5)) + 
    theme(axis.text.y = element_text(size = 10, family = "sans"), axis.title = element_text(size = 12, family = "sans"), axis.line = element_line(colour = "grey", size = 0.5)) + 
    theme(strip.text.x = element_text(size = 10, face = "bold", family = "sans"), strip.background = element_rect(colour = "grey", size = 0.5)) +                                  #increases size of text (facet wrap labels)
    theme(panel.spacing.x=unit(4, "lines")) +                                                       #increases white space between the two plots of the facet wrap
    ggplot2::scale_y_continuous(limits = c(-100, 100), breaks = seq(-100, 100, by = 100), labels = signs_format()) +                                #sets intervals of y-axis to every 100
    ggplot2::scale_x_continuous(limits = c(-100, 100), breaks = seq(-100, 100, by = 100), labels = signs_format()) +                                #sets intervals of x-axis to every 100#sets intervals of x-axis to every 100
    geom_text(
      data = r2, 
      mapping = aes(x = x, y = y, label = paste("~italic(r)^2==", label)), 
      parse = TRUE, size = 14 / .pt, family = "sans") +
    theme(
      #plot.title = element_text(size = 12, hjust = 0.5), 
      plot.subtitle = element_text(size = 14, hjust = c(-0.05,0.5), family = "sans") 
    )
  
  
}




#(save as horizonal pdf individually)
Study2A_con <- control_plot(control_2A, "2A", "Food Name Only",  r2_2A_con)
Study2B_con <- control_plot(control_2B, "2B", "Food Name Only", r2_2B_con)
Study2C_con <- control_plot(control_2C, "2C", "Food Name Only", r2_2C_con)



#add grey box that says "Control Condition" 

p <- ggdraw() +
  geom_hline(yintercept = 0.5, size = 15, colour = "lightgrey", alpha = 0.5) +
  draw_label(
    "Control Condition",
    size = 16,
    fontface = 'plain',
    x = 0.5#,
    #  hjust = 0
  ) +
  geom_hline(yintercept = 0.1, size = 0.5, colour = "black") +
  geom_hline(yintercept = 0.90, size = 0.5, colour = "black")


#merge all control plots for Figure 2 (save as vertical A4 pdf combined) 
controls <- plot_grid(
  Study2A_con, Study2B_con, Study2C_con,
  ncol = 1#,
  # rel_heights values control vertical title margins
  # rel_heights = c(0.2, 1)
)


#merge control plots with title 

# #merge title with scatterplot
controls <- plot_grid(
  p, controls,
  ncol = 1,
  # rel_heights values control vertical title margins
  rel_heights = c(0.05, 1)
)





exp_plot = function(df, stimulus, r2){
  
  
  # create function to make a scatterplot for each condition
  sp = ggplot(df, aes(x = actual_rating, y = predicted_rating)) +
    labs(
      x = "Actual Ratings", y = "Predicted Ratings",
      #title = participant_sample, 
      subtitle = c(stimulus)) +
    geom_point(aes(color = model), size = 2, alpha = 0.6) +                                         #size of each data point (n = 172 food items)
    geom_smooth(aes(color = model, fill = model),method = "lm", fullrange = TRUE, formula = y ~ x, size = 2.5) +  #r squared line                       #r square value
    facet_wrap(~model, scales = "fixed") +                                                          #separates data for VR and N computational models 
    scale_color_manual(values = c("#21908CFF", "#3B528BFF", "#440154FF")) +   #viridis manual  #colours used to distinguish between computational models
    scale_fill_manual(values = c("#21908CFF", "#3B528BFF", "#440154FF")) +    #colours used to distinguish between computational models
    theme_pubr(legend = "none") +                                                   #increases font size of x-axis and y-axis labels and removes legend 
    theme(axis.text.x = element_text(size = 10, family = "sans"), axis.title = element_text(size = 12, family = "sans"), axis.line = element_line(colour = "grey", size = 0.5)) + 
    theme(axis.text.y = element_text(size = 10, family = "sans"), axis.title = element_text(size = 12, family = "sans"), axis.line = element_line(colour = "grey", size = 0.5)) + 
    theme(strip.text.x = element_text(size = 10, face = "bold", family = "sans"), strip.background = element_rect(colour = "grey", size = 0.5)) +                                  #increases size of text (facet wrap labels)
    theme(panel.spacing.x=unit(4, "lines")) +                                                       #increases white space between the two plots of the facet wrap
    ggplot2::coord_cartesian(ylim = c(-100, 100), xlim = c(-100, 100)) +                            #sets the min and max of x-axis and y-axis to -100 and 100
    ggplot2::scale_y_continuous(breaks = seq(-100, 100, by = 100), labels = signs_format()) +                                #sets intervals of y-axis to every 100
    ggplot2::scale_x_continuous(breaks = seq(-100, 100, by = 100), labels = signs_format()) +                                 #sets intervals of x-axis to every 100
    geom_text(
      data = r2, 
      mapping = aes(x = x, y = y, label = paste("~italic(r)^2==", label)), 
      parse = TRUE, size = 14 / .pt, family = "sans") +
    theme(
      #plot.title = element_text(size = 12, hjust = 0.5), 
      plot.subtitle = element_text(size = 14, hjust = c(0.5), family = "sans") 
    )
  
  
}


Study2A_exp <- exp_plot(exp_2A, "Food Name + Calorie Labeling", r2_2A_exp)
Study2B_exp <- exp_plot(exp_2B, "Food Name + Front-of-Pack Labeling", r2_2B_exp)
Study2C_exp <- exp_plot(exp_2C, "Food Name + Traffic Light Labeling", r2_2C_exp)


#add grey box that says "Treatment Condition" 

q <- ggdraw() +
  geom_hline(yintercept = 0.5, size = 15, colour = "lightgrey", alpha = 0.5) +
  draw_label(
    "Treatment Condition",
    size = 16,
    fontfamily = "sans",
    fontface = 'plain',
    x = 0.5#,
    #  hjust = 0
  ) +
  geom_hline(yintercept = 0.1, size = 0.5, colour = "black") +
  geom_hline(yintercept = 0.90, size = 0.5, colour = "black")


#merge all control plots for Figure 2 (save as vertical A4 pdf combined) 
exps <- plot_grid(
  Study2A_exp, Study2B_exp, Study2C_exp,
  ncol = 1#,
  # rel_heights values control vertical title margins
  # rel_heights = c(0.2, 1)
)


#merge control plots with title 

# #merge title with scatterplot
exps <- plot_grid(
  q, exps,
  ncol = 1,
  # rel_heights values control vertical title margins
  rel_heights = c(0.05, 1)
)



plot_grid(
  controls, exps,
  ncol = 2,
  # rel_heights values control vertical title margins
 # rel_heights = c(1, 1)
 align = "hv"
)


ggsave("Figure_6.pdf", dpi = 300, width = 42, height = 29.7, units = "cm")
