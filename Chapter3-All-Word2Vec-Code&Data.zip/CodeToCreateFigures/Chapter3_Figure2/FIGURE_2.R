# Code Overview -----------------------------------------------------------

# R Code to reproduce Figure 2: LOOCV results for the Nutrient Model, Vector Representation Model, and Combined Model used in "Computational Methods for Predicting and Understanding Food Judgment"
# Written by Natasha Gandhi
# email: n.gandhi.1@warwick.ac.uk
# last update: 2021 07 21

# Outline:

# [1] Load Data and Cleanup:

## control_1 = Study 1A (Food Name only): N Model, VR Model and C Model
## exp_1 = Study 1B (Food Name only: Dietitians): N Model, VR Model and C Model 
## exp_1c = Study 1C (Food Name + Image): N Model, VR Model and C Model 




# Packages needed ---------------------------------------------------------

# Data Cleaning 
library(data.table)
library(dplyr)

# Data Visualisation
library(ggplot2)
library(ggpubr) #publication ready plots
library(cowplot) #combine figures 
library(viridis)


library(colorspace)
library(colorblindr)

library(signs) #replaces hyphen (U+002D)  in plots with true minus sign (U+2212)  



# Load Data and Cleanup ------------------------------------------------------


## Read in data for Study 1 (control vs experts)
control_1 <- fread("Control_1_AllModels.csv", stringsAsFactors = FALSE, na.strings = "")
exp_1 <- fread("Exp_1_AllModels.csv", stringsAsFactors = FALSE, na.strings = "")
exp_1c <- fread("Exp_1c_AllModels.csv", stringsAsFactors = FALSE, na.strings = "")

##Add column for Study
control_1[,Study := "Study 1A (Control)"]
exp_1[,Study := "Study 1B (Experts)"]
exp_1c[,Study := "Study 1C (Food Images)"]


# create function to manually set order of the computational models in the plot 
#(Vector Representation Model = left, Nutrient Model = right) 
neworder <- function(df){
  neworder <- c("Nutrient Model","Vector Representation Model", "Combined Model");
  no = arrange(mutate(df, model = factor(model, levels = neworder)), model)
}

#apply function to each dataset
control_1 <- neworder(control_1)
exp_1 <- neworder(exp_1)
exp_1c <- neworder(exp_1c)



r2_1A <- data.frame(
  x = -60, y = 95,
  label = c("0.35", "0.76", "0.77"),
  model   = factor(c("Nutrient Model", "Vector Representation Model", "Combined Model"), levels = c("Nutrient Model", "Vector Representation Model", "Combined Model")))#,

r2_1B <- data.frame(
  x = -60, y = 95,
  label = c("0.39", "0.69", "0.75"),
  model   = factor(c("Nutrient Model", "Vector Representation Model", "Combined Model"), levels = c("Nutrient Model", "Vector Representation Model", "Combined Model")))#,

r2_1C <- data.frame(
  x = -60, y = 95,
  label = c("0.37", "0.75", "0.76"),
  model   = factor(c("Nutrient Model", "Vector Representation Model", "Combined Model"), levels = c("Nutrient Model", "Vector Representation Model", "Combined Model")))#,



# Scatterplots for each condition -----------------------------------------

 plot = function(df, participant_sample, study, stimulus, r2){
  

   p <- ggdraw() +
     geom_hline(yintercept = 0.5, size = 10, colour = "lightgrey", alpha = 0.5) +
     draw_label(
       participant_sample,
       size = 12,
       fontfamily = 'sans',
       fontface = 'plain',
       x = 0.5#,
       #  hjust = 0
     ) +
     geom_hline(yintercept = 0.1, size = 0.5, colour = "black") +
     geom_hline(yintercept = 0.90, size = 0.5, colour = "black")



  # create function to make a scatterplot for each condition
  sp = ggplot(df, aes(x = actual_rating, y = predicted_rating)) +
  labs(
    x = "Actual Ratings", y = "Predicted Ratings",
    #title = participant_sample, 
    subtitle = c(study, stimulus)) +
    geom_point(aes(color = model), size = 2, alpha = 0.6) +                                         #size of each data point (n = 172 food items)
    geom_smooth(aes(color = model, fill = model),method = "lm", fullrange = TRUE, formula = y ~ x, size = 2.5) +  #r squared line                       #r square value
    facet_wrap(~model, scales = "fixed") +                                                          #separates data for VR and N computational models 
   # scale_fill_viridis_d(direction = 1) +
   # scale_colour_viridis_d(direction = 1) +
    scale_color_manual(values = c("#21908CFF", "#3B528BFF", "#440154FF")) +   #viridis manual  #colours used to distinguish between computational models
    scale_fill_manual(values = c("#21908CFF", "#3B528BFF", "#440154FF")) + 
                                           
    theme_pubr(legend = "none") +                                                   #increases font size of x-axis and y-axis labels and removes legend 
    theme(axis.text = element_text(size = 9, family = "sans"), axis.title = element_text(size = 10, family = "sans"), axis.line = element_line(colour = "grey", size = 0.5)) + 
    theme(strip.text.x = element_text(size = 9, face = "bold", family = "sans"), strip.background = element_rect(colour = "grey", size = 0.5)) + #increases size of text (facet wrap labels)
    theme(panel.spacing.x=unit(4, "lines")) +                                                       #increases white space between the two plots of the facet wrap                       #sets the min and max of x-axis and y-axis to -100 and 100
    ggplot2::scale_y_continuous(limits = c(-100, 100), breaks = seq(-100, 100, by = 100), labels = signs_format()) +                                #sets intervals of y-axis to every 100
    ggplot2::scale_x_continuous(limits = c(-100, 100), breaks = seq(-100, 100, by = 100), labels = signs_format()) +                                 #sets intervals of x-axis to every 100
    geom_text(
      data = r2, 
      mapping = aes(x = x, y = y, label = paste("~italic(r)^2==", label)), 
      parse = TRUE, size = 10 / .pt, family = "sans") +
  theme(
    #plot.title = element_text(size = 12, hjust = 0.5), 
    plot.subtitle = element_text(size = 12, hjust = c(-0.05,0.5), family = "sans") 
  )
  
  # #merge title with scatterplot
  plot_grid(
    p, sp,
    ncol = 1,
    # rel_heights values control vertical title margins
    rel_heights = c(0.1, 1)
  )
  
  
}




#(save as horizonal pdf individually)
Study1A <- plot(control_1,"General Population Sample", "1A", "Food Name Only",  r2_1A)
Study1B <- plot(exp_1, "Registered Dietitian Sample", "1B", "Food Name Only", r2_1B)
Study1C <- plot(exp_1c, "General Population Sample", "1C", "Food Name + Image", r2_1C)


# cvd_grid(Study1A)

#merge all plots for Figure 2 (save as vertical pdf combined)
plot_grid(
  Study1A, Study1B, Study1C,
  ncol = 1#,
  # rel_heights values control vertical title margins
 # rel_heights = c(0.2, 1)
)


ggsave("Figure2.pdf", dpi = 300, width = 21, height = 29.7, units = "cm")




