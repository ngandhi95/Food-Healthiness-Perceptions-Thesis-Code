
# Code Overview -----------------------------------------------------------

# R Code to reproduce Figure 1: Study 1A Food Ratings Summary used in Thesis: "Understanding individual food healthiness perceptions using a computational approach"
# Written by Natasha Gandhi
# email: n.gandhi.1@warwick.ac.uk
# last update: 2019 10 11 

# Outline:

# [1] Load Participant Data and Cleanup:
## S1A = Study 1A - Aggregate Healthiness Ratings from a General Population sample [given food name only]

# [2] Aggregate Healthiness Ratings For Each Food Item Per Condition
##Data Summary Table (means, min, max, standard deviation and standard error)

# Packages needed ---------------------------------------------------------

# Data Cleaning 
library(data.table)
library(dplyr)

# Data Visualisation
library(ggplot2)
library(ggpubr) #publication ready plots
library(cowplot) #combine figures 
library(ggrepel)


library(signs) #replaces hyphen (U+002D)  in plots with true minus sign (U+2212)  

# library(extrafont)
# font_import()
# loadfonts()

# Load Data and Cleanup ------------------------------------------------------


## import raw nutrient info for the food items 
food <- fread("nutrients info.csv", stringsAsFactors = FALSE, na.strings = "")[, c("food_name", "food_cat")]
S1A <-  fread("Study1A_Summary.csv", stringsAsFactors = FALSE, na.strings = "")[,-1]

## add food category information to the dataset with food ratings 
S1A <- merge(S1A, food, by = "food_name")

## order the food items by mean ratings (unhealthiest is first)
setorder(S1A, mean)

#convert food category class to factor to change the order of the food categories
S1A$food_cat <- as.factor(S1A$food_cat)
levels <- c("Vegetables and Vegetable Products", "Fruits and Fruit Juices", "Nut and Seed Products", "Legumes and Legume Products", "Cereal Grains and Pasta", "Breakfast Cereals", "Fats and Oils", "Dairy and Egg Products", "Baked Products", "Beverages", "Sweets", "Snacks", "Finfish and Shellfish Products", "Poultry Products", "Sausages and Luncheon Meats", "Pork Products", "Lamb, Veal, and Game Products", "Beef Products", "Soups, Sauces, and Gravies", "Meals, Entrees, and Side Dishes")
S1A$food_cat <- factor(S1A$food_cat, levels = levels)


# Create Figure showing distribution of aggregate ratings ------------------------------------------------------

#allows all data points to be shown even if overlapping occurs 
options(ggrepel.max.overlaps = Inf)



## save as 1500 (width) 800 height 
S1A_plot <- ggdotchart(S1A, x="food_name", y = "mean",
                       color = "food_cat",
                       sorting = "descending", 
                       sort.by.groups = TRUE,
                       add = "segments",
                       add.params = list(color = "lightgray", size = 0.5),
                       group = "food_cat",
                       dot.size = 3,
                       ylab = "Aggregate Healthiness Rating",
                       label = "food_name",
                       label.select = c(label.select = c("broccoli", "baked_sweet_potato", "mashed_potatoes", "french_fries", "apple", "raisins", "roasted_peanuts", "peanut_butter", "chickpeas", "quinoa", "cheerios", "lard", "multigrain_bagel", "croissant", "cheesecake", "donut", "tea", "aloe_vera_juice", "lemonade", "beer", "brandy", "cola", "skittles", "kit_kat", "brown_sugar", "dark_chocolate", "honey", "smoked_salmon", "popcorn", "chicken_breast", "guacamole", "vegetable_broth", "sushi", "pad_thai", "chicken_curry", "lasagna", "cheeseburger")),                       
                       repel = TRUE,
                       label.rectangle = TRUE,
                       font.label = list(size = 9, face = "plain", family = "sans")) +
  ggplot2::scale_y_continuous(limits = c(-100, 100), breaks = seq(-100, 100, by = 50), labels = signs_format()) +    
  scale_color_viridis_d(option = 5) + #viridis #plasma #5 #7 #13
  theme(axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        axis.title.x = element_blank(),
        axis.line.x = element_blank()) +
        theme(axis.text.y = element_text(size = 9, family = "sans"), axis.title.y = element_text(size = 10, family = "sans")) +
        theme(legend.text = element_text(size = 9, family = "sans"), legend.title = element_text(size = 9, family = "sans")) +
  labs(colour = "Food Categories")



ggsave("Figure1.pdf", dpi = 300, width = 29.7, height = 21, units = "cm")



