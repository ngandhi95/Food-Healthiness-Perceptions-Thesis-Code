
# Code Overview -----------------------------------------------------------

# R Code to reproduce Figures used in thesis: "Understanding individual food healthiness perceptions using a computational approach"
# Written by Natasha Gandhi
# email: n.gandhi.1@warwick.ac.uk
# last update: 2019 08 30

# Outline:

# [1] Load Data and Cleanup:
## Study 2A (Control vs Calorie Information) 
# VR Model
## Study 2B (Control vs Front of Package Labelling Information) 
# VR Model
## Study 2C (Control vs Traffic Light Labelling Colour Information) 
# VR Model


# [2] Scatterplots for study with manipulation to the food stimuli presentation:
## S[X]_VRM_plot = ggplot for each study
## cowplot = combined ggplots


# Packages needed ---------------------------------------------------------

# Data Cleaning 
library(data.table)
library(dplyr)

# Data Visualisation
library(ggplot2)
library(ggpubr) #publication ready plots
library(cowplot) #combine figures 

library(signs) #replaces hyphen (U+002D)  in plots with true minus sign (U+2212)  




# Load Data and Cleanup ------------------------------------------------------

### Read in data for S1A 
S2A <- fread("S2A_Differences.csv", stringsAsFactors = FALSE, na.strings = "")
S2B <- fread("S2B_Differences.csv", stringsAsFactors = FALSE, na.strings = "")
S2C <- fread("S2C_Differences.csv", stringsAsFactors = FALSE, na.strings = "")


##Add column for Study
S2A[,Study := "Control vs Calorie Labelling"]
S2B[,Study := "Control vs FoP Labelling"]
S2C[,Study := "Control vs TL Labelling"]


# Separate Vector Representation Model data only from dataset  -----------------

S2A <- S2A[model != "Nutrient Model"]
S2B <- S2B[model != "Nutrient Model"]
S2C <- S2C[model != "Nutrient Model"]


# create function to manually set order of the computational models in the plot 
#(Vector Representation Model = left, Combined Model = right)
neworder <- function(df){
  neworder <- c("Vector Representation Model", "Combined Model");
  no = arrange(mutate(df, model = factor(model, levels = neworder)), model)
}

# #apply function to each dataset

S2A <- neworder(S2A)
S2B <- neworder(S2B)
S2C <- neworder(S2C)

# S2$model <- factor(S2$model,levels=c("Vector Representation Model","Combined Model"))


# Obtain adjusted R-squared values ----------------------------------------

r2_2A <- data.frame(
  x = -14, y = 15,
  label = c("0.34", "0.46"),
  model   = factor(c("Vector Representation Model", "Combined Model"), levels = c("Vector Representation Model", "Combined Model")))#,

r2_2B <- data.frame(
  x = -28, y = 15,
  label = c("0.19", "0.55"),
  model   = factor(c("Vector Representation Model", "Combined Model"), levels = c("Vector Representation Model", "Combined Model")))#,

r2_2C <- data.frame(
  x = -48, y = 50,
  label = c("0.29", "0.69"),
  model   = factor(c("Vector Representation Model", "Combined Model"), levels = c("Vector Representation Model", "Combined Model")))#,


# Scatterplots for each Study -----------------------------------------


plot = function(df, study, r2){
  
  # create function to make a scatterplot for each condition
  
  ggplot(df, aes(x = actual_difference, y = predicted_difference)) +
    labs(
      x = "Actual Difference Between Conditions", y = "Predicted Difference Between Conditions",
      subtitle = study) +
    geom_point(aes(color = model), size = 2, alpha = 0.6) +
    geom_smooth(aes(color = model, fill = model), 
                method = "lm", fullrange = TRUE, formula = y ~ x, size = 2.5) +
    # geom_text(data=r2_S2, size = 10, aes(x=-12,y=25,label= eq), parse=TRUE) +
    facet_wrap(~model) +
    scale_color_manual(values = c("#3B528BFF", "#440154FF")) +   #viridis manual  #colours used to distinguish between computational models
    scale_fill_manual(values = c("#3B528BFF", "#440154FF")) + 
    theme_pubr(legend = "none") +
    theme(axis.text = element_text(size = 18 , family = "sans"), axis.title = element_text(size = 20, family = "sans"), axis.line = element_line(colour = "grey", size = 0.5)) + 
    theme(strip.text.x = element_text(size = 18, face = "bold", family = "sans"), strip.background = element_rect(colour = "grey", size = 0.5)) +  
    ggplot2::scale_y_continuous(labels = signs_format()) +                                #sets intervals of y-axis to every 100
    ggplot2::scale_x_continuous(labels = signs_format()) +                                #sets intervals of x-axis to every 100#sets intervals of x-axis to every 100
    geom_text(
      data = r2, 
      mapping = aes(x = x, y = y, label = paste("~italic(r)^2==", label)), 
      parse = TRUE, size = 22 / .pt, family = "sans") +
    theme(plot.subtitle = element_text(size = 22, hjust = 0.5, family = "sans")) +
    theme(panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
  
}



#(save as horizonal pdf individually)
Study2A <- plot(S2A, "Study 2A", r2_2A)
Study2B <- plot(S2B, "Study 2B", r2_2B)
Study2C <- plot(S2C, "Study 2C", r2_2C)



# save as 3000 (width) and 800 (height)
# save as 23.4 inch and 8 or 10 inch (height) as pdf
cowplot <- plot_grid(Study2A, Study2B, Study2C, 
                     #labels = c("auto"), label_size = 30, 
                     nrow = 1, 
                     align = "hv")


p <- ggdraw() +
  geom_hline(yintercept = 0.5, size = 20, colour = "lightgrey", alpha = 0.5) +
  draw_label(
    "General Population Sample",
    size = 24,
    fontfamily = "sans",
    fontface = 'plain',
    x = 0.5#,
    #  hjust = 0
  ) +
  geom_hline(yintercept = 0.1, size = 0.5, colour = "black") +
  geom_hline(yintercept = 0.90, size = 0.5, colour = "black")


# #merge title with scatterplot
plot_grid(
  p, cowplot,
  ncol = 1,
  # rel_heights values control vertical title margins
  rel_heights = c(0.1, 1)
)



ggsave("Figure7.pdf", dpi = 300, width = 24, height = 8, units = "in")
