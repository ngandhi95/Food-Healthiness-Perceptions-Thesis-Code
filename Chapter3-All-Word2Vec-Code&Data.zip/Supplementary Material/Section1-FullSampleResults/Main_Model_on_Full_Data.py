# -*- coding: utf-8 -*-
"""

Paper: "Computational Methods for Predicting and Understanding Food Judgment"

Section 1 of the Supplementary Materials

Outline:
    
[I] Aggregate level model fits on raw data without exclusion for the three main models 
    - 1. Vector Representation Model
    - 2. Nutrient Model 
    - 3. Combined Model

"""

'''load packages and data'''

import pickle
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import LeaveOneOut
from sklearn.metrics import r2_score

with open("Path where the pickle file is stored/dict_of_Xs.pickle", "rb") as handle:
    dict_of_Xs = pickle.load(handle)

dict_of_ys={}
studies = ['1A', '1B', '1C', '2A_control', '2A_treatment', '2B_control', '2B_treatment', '2C_control', '2C_treatment']
for study in studies:
    df = pd.read_excel(r'Path where the Excel file is stored\mega_results.xlsx', sheet_name=study, header=None)
    df.columns = ['food'] + [f'Participant_{n}' for n in range(len(df.columns)-1)]
    df = df.set_index(['food']).T
    judgment_means = df.mean()
    judgment_means.name = 'judgment'
    dict_of_ys[study] = judgment_means

##################################################################
################ 1. Vector Representation Model ##################
##################################################################
dict_of_vrm_pred={}
for study in studies:
    X = dict_of_Xs['word2vec'].values
    y = dict_of_ys[study].values
    y_pred = np.zeros(shape=len(y))
    for train_index, test_index in LeaveOneOut().split(X):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]
        y_pred[test_index] = Ridge(alpha=1).fit(X_train,y_train).predict(X_test)
    dict_of_vrm_pred[study] =  y_pred
    print(study, r2_score(y,y_pred))
"""
1A 0.7566127660140055
1B 0.6881519168776286
1C 0.7550121354819241
2A_control 0.767309053824214
2A_treatment 0.7583287360128457
2B_control 0.7614311089137584
2B_treatment 0.7389026911340937
2C_control 0.7593567417543088
2C_treatment 0.6518809812439321
"""

#############################################################
################ 2. Nutrient Content Model ##################
#############################################################
dict_of_nm_pred={}
for study in studies:
    X = dict_of_Xs['nutrient'].values
    y = dict_of_ys[study].values
    y_pred = np.zeros(shape=len(y))
    for train_index, test_index in LeaveOneOut().split(X):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]
        y_pred[test_index] = LinearRegression().fit(X_train, y_train).predict(X_test)
    dict_of_nm_pred[study] =  y_pred
    print(study, r2_score(y,y_pred))
"""
1A 0.3516959355877437
1B 0.3908910775062644
1C 0.3678204889581739
2A_control 0.33467773116652366
2A_treatment 0.4515248398491529
2B_control 0.3388267551558768
2B_treatment 0.5323005896613496
2C_control 0.35726775524058607
2C_treatment 0.773945452090762
"""

#####################################################
################ 3. Combined Model ##################
#####################################################
dict_of_cm_pred={}
for study in studies:
    X = dict_of_Xs['combined'].values
    y = dict_of_ys[study].values
    y_pred = np.zeros(shape=len(y))
    for train_index, test_index in LeaveOneOut().split(X):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]
        y_pred[test_index] = Ridge(alpha=1).fit(X_train,y_train).predict(X_test)
    dict_of_cm_pred[study] = y_pred
    print(study, r2_score(y,y_pred))
"""
1A 0.7643436661416765
1B 0.7513700468382586
1C 0.7692929575518566
2A_control 0.7736116735682006
2A_treatment 0.809516188442421
2B_control 0.7708152226035745
2B_treatment 0.8249117340052516
2C_control 0.7736204698731394
2C_treatment 0.9111671135983999
"""



''' calculate 95% CIs '''
def se(r2,k):
    return ((4*r2*(1-r2)**2*(172-k-1)**2)/((172**2-1)*175))**0.5
r2_ci=pd.DataFrame(columns=studies, 
                   index=['VRM','VRM-L','VRM-U','NM','NM-L','NM-U','CM','CM-L','CM-U'])        
for study in studies:
    y=dict_of_ys[study].values
    y_pred_vrm=dict_of_vrm_pred[study]
    y_pred_nm=dict_of_nm_pred[study]
    y_pred_cm=dict_of_cm_pred[study]
    vrm=float(r2_score(y,y_pred_vrm))
    vrm_l=vrm-2*se(vrm,300)
    vrm_u=vrm+2*se(vrm,300)
    nm=float(r2_score(y,y_pred_nm))
    nm_l=nm-2*se(nm,11)
    nm_u=nm+2*se(nm,11)
    cm=float(r2_score(y,y_pred_cm))
    cm_l=cm-2*se(cm,311)
    cm_u=cm+2*se(cm,311)
    r2_ci[study]=[vrm,vrm_l,vrm_u,nm,nm_l,nm_u,cm,cm_l,cm_u]
r2_ci.T.to_csv('Path where you want to store the outputs/name of the output file.csv')
