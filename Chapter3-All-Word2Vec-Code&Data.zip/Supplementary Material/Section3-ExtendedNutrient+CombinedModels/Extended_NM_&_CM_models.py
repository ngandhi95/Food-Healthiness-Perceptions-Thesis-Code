# -*- coding: utf-8 -*-
"""

Paper: "Computational Methods for Predicting and Understanding Food Judgment"

Section 3 of the Supplementary Materials

Outline:
    
[I] Predicted Healthiness Ratings obtained using extended models (additional nutrients and per 100kcal)
    - 1. Nutrient Model
    - 2. Combined Model



"""


############################################################################
########## 1. Extended Nutrient Model (33 Nutrients per 100kcal) ###########
############################################################################

'''load packages '''

import csv
import numpy as np
import gensim.models as models
import pandas as pd
from scipy.stats.stats import pearsonr
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import Normalizer
from sklearn.model_selection import LeaveOneOut
from pattern.text.en import singularize
from sklearn.metrics import r2_score


# path
word2vec = models.KeyedVectors.load_word2vec_format(r'Path where word2vec is downloaded to\oogleNews-vectors-negative300.bin.gz', binary=True)

# home office path
#word2vec = models.KeyedVectors.load_word2vec_format(r'D:\OneDrive - University of Warwick\Vector Semantic Models\Google word2vec\GoogleNews-vectors-negative300.bin.gz' , binary=True)




extendedNM_1A=pd.read_csv(r'Path where the CSV file is stored/eNM_1A.csv')
extendedNM_1B=pd.read_csv(r'Path where the CSV file is stored/eNM_1B.csv')
extendedNM_1C=pd.read_csv(r'Path where the CSV file is stored/eNM_1C.csv')


extendedNM_2A_con=pd.read_csv(r'Path where the CSV file is stored/eNM_2A_con.csv')
extendedNM_2A_exp=pd.read_csv(r'Path where the CSV file is stored/eNM_2A_exp.csv')

extendedNM_2B_con=pd.read_csv(r'Path where the CSV file is stored/eNM_2B_con.csv')
extendedNM_2B_exp=pd.read_csv(r'Path where the CSV file is stored/eNM_2B_exp.csv')

extendedNM_2C_con=pd.read_csv(r'Path where the CSV file is stored/eNM_2C_con.csv')
extendedNM_2C_exp=pd.read_csv(r'Path where the CSV file is stored/eNM_2C_exp.csv')



actual=extendedNM_1A['Actual'] 
pred=extendedNM_1A['Predicted']  
        
actual=extendedNM_1B['Actual']
pred=extendedNM_1B['Predicted']

actual=extendedNM_1C['Actual']
pred=extendedNM_1C['Predicted']

actual=extendedNM_2A_con['Actual']  
pred=extendedNM_2A_con['Predicted']  

actual=extendedNM_2A_exp['Actual'] 
pred=extendedNM_2A_exp['Predicted'] 

actual=extendedNM_2B_con['Actual']  
pred=extendedNM_2B_con['Predicted'] 

actual=extendedNM_2B_exp['Actual'] 
pred=extendedNM_2B_exp['Predicted'] 

actual=extendedNM_2C_con['Actual']  
pred=extendedNM_2C_con['Predicted']  

actual=extendedNM_2C_exp['Actual'] 
pred=extendedNM_2C_exp['Predicted'] 



loocv_extendedNM_1A=r2_score(actual,pred)  #0.12034680044975865 for Study 1A Control
loocv_extendedNM_1B=r2_score(actual,pred)  #0.13840774353251428 for Study 1B Experimental (Experts)
loocv_extendedNM_1C=r2_score(actual,pred)  #0.10221243224122789 for Study 1C Experimental (Food Images)


loocv_extendedNM_2A_con=r2_score(actual,pred) #0.07462207868263093 for Study 2A Control
loocv_extendedNM_2A_exp=r2_score(actual,pred) #0.2391766486868413 for Study 2A Experimental (Calories) 

loocv_extendedNM_2B_con=r2_score(actual,pred) #0.11482028463422134 for Study 2B Control
loocv_extendedNM_2B_exp=r2_score(actual,pred) #0.3517850385284541 for Study 2B Experimental (FoP labelling)

loocv_extendedNM_2C_con=r2_score(actual,pred) #0.09431857556046874 for Study 2C Control
loocv_extendedNM_2C_exp=r2_score(actual,pred) #0.7169760724156713 for Study 2C Experimental (TLL labelling)





############################################################################
########## 2. Extended Combined Model (33 Nutrients per 100kcal) ###########
############################################################################


extendedCM_1A=pd.read_csv(r'Path where the CSV file is stored/eCM_1A.csv')
extendedCM_1B=pd.read_csv(r'Path where the CSV file is stored/eCM_1B.csv')
extendedCM_1C=pd.read_csv(r'Path where the CSV file is stored/eCM_1C.csv')


extendedCM_2A_con=pd.read_csv(r'Path where the CSV file is stored/eCM_2A_con.csv')
extendedCM_2A_exp=pd.read_csv(r'Path where the CSV file is stored/eCM_2A_exp.csv')

extendedCM_2B_con=pd.read_csv(r'Path where the CSV file is stored/eCM_2B_con.csv')
extendedCM_2B_exp=pd.read_csv(r'Path where the CSV file is stored/eCM_2B_exp.csv')

extendedCM_2C_con=pd.read_csv(r'Path where the CSV file is stored/eCM_2C_con.csv')
extendedCM_2C_exp=pd.read_csv(r'Path where the CSV file is stored/eCM_2C_exp.csv')



actual=extendedCM_1A['Actual'] 
pred=extendedCM_1A['Predicted']  
        
actual=extendedCM_1B['Actual']
pred=extendedCM_1B['Predicted']

actual=extendedCM_1C['Actual']
pred=extendedCM_1C['Predicted']

actual=extendedCM_2A_con['Actual']  
pred=extendedCM_2A_con['Predicted']  

actual=extendedCM_2A_exp['Actual'] 
pred=extendedCM_2A_exp['Predicted'] 

actual=extendedCM_2B_con['Actual']  
pred=extendedCM_2B_con['Predicted'] 

actual=extendedCM_2B_exp['Actual'] 
pred=extendedCM_2B_exp['Predicted'] 

actual=extendedCM_2C_con['Actual']  
pred=extendedCM_2C_con['Predicted']  

actual=extendedCM_2C_exp['Actual'] 
pred=extendedCM_2C_exp['Predicted'] 




loocv_extendedCM_1A=r2_score(actual,pred) #0.73520024933629 for Study 1A Control
loocv_extendedCM_1B=r2_score(actual,pred) #0.6749250070780964 for Study 1B Experimental (Experts)
loocv_extendedCM_1C=r2_score(actual,pred) #0.7317212627050315 for Study 1C Experimental (Food Images)

loocv_extendedCM_2A_con=r2_score(actual,pred) #0.7343234211204721 for Study 2A Control
loocv_extendedCM_2A_exp=r2_score(actual,pred) #0.766542241081474 for Study 2A Experimental (Calories) 

loocv_extendedCM_2B_con=r2_score(actual,pred) #0.7345070843582883 for Study 2B Control
loocv_extendedCM_2B_exp=r2_score(actual,pred) #0.7857289874727555 for Study 2B Experimental (FoP labelling)

loocv_extendedCM_2C_con=r2_score(actual,pred) #0.740140745212015 for Study 2C Control
loocv_extendedCM_2C_exp=r2_score(actual,pred) #0.8869598704038105 for Study 2C Experimental (TLL labelling)



