# -*- coding: utf-8 -*-
"""

Paper: "Computational Methods for Predicting and Understanding Food Judgment"

Sections 10 of the Supplementary Materials

Outline:
    
[I] Test of Model Generalizability
    - 1. Get predicted healthiness ratings from the Vector Representation Model trained on Study 1A
    - 2. Paired t-test for VRM predictions vs. aggregate human ratings
    - 3. Paired t-test for VRM predictions vs. individual human ratings
  
"""

'''load packages and data'''

import pandas as pd
import pickle
import numpy as np
import gensim.models as models
from sklearn.preprocessing import Normalizer
import scipy.stats as stats
from sklearn.linear_model import Ridge

word2vec = models.KeyedVectors.load_word2vec_format(r'Path where the embeddings file is stored\GoogleNews-vectors-negative300.bin.gz', binary=True)
new_ratings=pd.read_csv(r'Path where the CSV file is stored\new_60_stimuli_rating_filtered.csv',index_col=0)
with open("Path where the pickle file is stored/dict_of_Xs.pickle", "rb") as handle:
    dict_of_Xs = pickle.load(handle)
with open("Path where the pickle file is stored/dict_of_ys.pickle", "rb") as handle:
    dict_of_ys = pickle.load(handle)

############################################################################
###################### 1. Predict healthiness ratings ######################
############################################################################
food=new_ratings.index.values
x=word2vec[food[0]]
for item in food[1:len(food)]:
    x=np.vstack((x,word2vec[item]))
nx=Normalizer().fit(x).transform(x)

X=dict_of_Xs['word2vec']
y=dict_of_ys['1A']

predictions=Ridge(alpha=1).fit(X,y).predict(nx)
new_ratings['prediction']=predictions

############################################################################
##### 2. Paired t-test for VRM predictions vs. aggregate human ratings #####
############################################################################
stats.ttest_rel(new_ratings['prediction'], new_ratings['mean'])
"""
Ttest_relResult(statistic=-0.3391711504088958, pvalue=0.7356850875344765)
"""

############################################################################
##### 3. Paired t-test for VRM predictions vs. individual human ratings ####
############################################################################
t=[]
p=[]
for i in new_ratings.columns[0:99]:
    new_ratings[i]=new_ratings[i].fillna(new_ratings['mean']) # fill na with aggregate ratings
    t.append(stats.ttest_rel(new_ratings['prediction'], new_ratings[i])[0])
    p.append(stats.ttest_rel(new_ratings['prediction'], new_ratings[i])[1])
ttest=pd.DataFrame(columns=['t','p'])
ttest['t']=t
ttest['p']=p
ttest.to_csv(r'Path where you want to store the outputs\name of the output file.csv')   
sum(1 if x>0.05 else 0 for x in p) # 53/99 participants with p>0.05
