# -*- coding: utf-8 -*-
"""

Paper: "Computational Methods for Predicting and Understanding Food Judgment"

Sections 4-7 of the Supplementary Materials

Outline: 
    
[I] Section 4: Alternative word embeddings (group level only)   
    - GloVe
    - fastText
    - Figure S1
   
[II] Section 5: Secondary vector representation models (group level only)
    - lasso, support vector, and k-nearest neighbours regressions
    - Figure S2
  
[III] Section 6: Group level model comparison
    - Vector Representation Model
    - Nutrient Model
    - Combined Model
    - Figure S3 
    - Table S6
    
[IV] Section 7: Individual level model fits
    - Vector Representation Model
    - Nutrient Model
    - Combined Model
    - Figure S4
  
"""

'''load packages and data'''

import pandas as pd
import pickle
import numpy as np
from sklearn.model_selection import LeaveOneOut
from sklearn.svm import SVR
from sklearn.linear_model import Ridge, Lasso, LinearRegression
from sklearn.neighbors import KNeighborsRegressor
import scipy.stats as stats
from sklearn.metrics import r2_score
from scipy.stats import pearsonr
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import Normalizer
import os
from ast import literal_eval
import io

with open("Path where the pickle file is stored/dict_of_Xs.pickle", "rb") as handle:
    dict_of_Xs = pickle.load(handle)
with open("Path where the pickle file is stored/dict_of_ys.pickle", "rb") as handle:
    dict_of_ys = pickle.load(handle)
with open("Path where the pickle file is stored/dict_of_individual_ys.pickle", "rb") as handle:
    dict_of_individual_ys = pickle.load(handle)
studies = ['1A', '1B', '1C', '2A_control', '2A_treatment', '2B_control', '2B_treatment', '2C_control', '2C_treatment']

###############################################################################
############# I. Alternative word embeddings (group level only)  ##############
###############################################################################
"""
dict_of_Xs.pickle already has the alternative word embeddings
To run the Vector Representation Model, skip to line 119
"""

with open("data/dict_of_Xs.pickle", "rb") as handle:
    dict_of_Xs = pickle.load(handle)
food=list(dict_of_Xs['word2vec'].index)

### loading GloVe
### following file can be downloaded from http://nlp.stanford.edu/data/glove.840B.300d.zip
f = open(r'glove.840B.300d.txt','r',encoding='UTF-8')
glove = {} 
for line in f:
    line2 = line.split(' ')
    line3 =  [float(l) for l in line2[1:len(line2)]]
    glove[line2[0]] = np.asarray(line3)

glove_vec={}
i=172
for item in food:
    vec=[]
    if item.replace('_','') in glove:
        vec=glove[item.replace('_','')]
        glove_vec[item]=Normalizer().fit(vec.reshape(1, -1)).transform(vec.reshape(1, -1))[0]
    else:
        i=i-1
dict_of_Xs['glove_111'] = pd.DataFrame(glove_vec).T

### loading FastText
def load_vectors(fname):
    fin = io.open(fname, 'r', encoding='utf-8', newline='\n', errors='ignore')
    n, d = map(int, fin.readline().split())
    fasttext_vec = {}
    for line in fin:
        tokens = line.rstrip().split(' ')
        fasttext_vec[tokens[0]] = list(map(float, tokens[1:]))
    return fasttext_vec

### following file can be downloaded from https://dl.fbaipublicfiles.com/fasttext/vectors-english/crawl-300d-2M.vec.zip
fasttext_model = load_vectors(r'crawl-300d-2M.vec')
   
ft_vec={}
i=172
for item in food:
    vec=[]
    if item.replace('_','') in fasttext_model:
        vec=np.asarray(fasttext_model[item.replace('_','')])
        ft_vec[item]=Normalizer().fit(vec.reshape(1, -1)).transform(vec.reshape(1, -1))[0]
    else:
        i=i-1
dict_of_Xs['ft_112'] = pd.DataFrame(ft_vec).T

### Vector Representation Model with word2ve, GloVe and fastText using LOOCV
vec_types = ['word2vec','ft_112','glove_111']
r2=np.zeros((3,9))
i=0
for vec_type in vec_types:
    j = 0
    X = dict_of_Xs[vec_type].values
    for study in studies:  
        y = pd.merge(left=dict_of_Xs[vec_type], right=dict_of_ys[study], left_index=True, right_index=True)['judgment'].values
        y_pred = np.zeros(shape=len(y))
        for train_index, test_index in LeaveOneOut().split(X):
            X_train, X_test = X[train_index], X[test_index]
            y_train, y_test = y[train_index], y[test_index]
            y_pred[test_index] = Ridge(alpha=1).fit(X_train,y_train).predict(X_test)
        r2[i][j]=r2_score(y, y_pred)
        j=j+1
    i=i+1
rsquared_df = pd.DataFrame(data=r2, index=vec_types, columns=studies).T

################################## Figure S1 ##################################
rsquared=rsquared_df.T
rsquared['average'] = rsquared.mean(axis=1)
cols = rsquared.columns.tolist()
cols = cols[-1:] + cols[:-1]
rsquared = rsquared[cols]
rsquared = rsquared.rename({'ft_112':'fastText','glove_111':'GloVe'}, axis='index')
fig, ax = plt.subplots(figsize=(10,8)) 
ax = sns.heatmap(rsquared.T, vmin=0, vmax=1, annot=True, cmap="Blues", cbar_kws={'label': 'Out-of-Sample $\it{r^2}$'}, annot_kws={"size": 15})
sns.set(font_scale=1.2)
plt.yticks(rotation=0)
plt.xlabel('Embedding Type', rotation='horizontal')
plt.ylabel('Study', rotation='vertical')
plt.savefig('Path where you want to save the figure\name of the figure.png', dpi=100)
plt.show()

###############################################################################
######## II. Secondary vector representation models (group level only) ########
###############################################################################
model_list = [
              (SVR,                 'svr_rbf'),
              (SVR,                 'svr_poly'),
              (SVR,                 'svr_sigmoid'),
              (Ridge,               'ridge'),
              (Lasso,               'lasso'), 
              (KNeighborsRegressor, 'knn')
               ]
arg_dicts_by_model = [
                         [{'kernel':'rbf', 'C':10**x, 'gamma':'auto'}       for x in range(-2,8)],
                         [{'kernel':'poly', 'C':10**x, 'gamma':'auto'}      for x in range(-2,8)],
                         [{'kernel':'sigmoid', 'C':10**x, 'gamma':'auto'}   for x in range(-2,8)],
                         [{'alpha':10**x}   for x in range(-2,8)],
                         [{'alpha':10**x}   for x in range(-2,8)],
                         [{'n_neighbors':x} for x in range(1,11)]
                      ]

xes = [['word2vec']]*9

r2=np.zeros((6,9,10))
i=0
for models, list_of_arg_dicts in zip(model_list, arg_dicts_by_model):
    model, model_name = models
    print(model_name)
    j = 0
    for study, xs in zip(studies, xes):  
        for x in xs:
            print('\t',study, x)
            X = dict_of_Xs[x].values
            y = dict_of_ys[study].values
            mean_rsquareds = []
            for arg_dicts in list_of_arg_dicts:
                print('\t','\t',arg_dicts)
                y_pred = np.zeros(shape=len(y))
                for train_index, test_index in LeaveOneOut().split(X):
                    X_train, X_test = X[train_index], X[test_index]
                    y_train, y_test = y[train_index], y[test_index]
                    regression = model(**arg_dicts) # refers to, e.g., svr(C=.01)
                    regression.fit(X=X_train, y=y_train)
                    y_pred[test_index] = regression.predict(X=X_test)
                mean_rsquareds.append(r2_score(y, y_pred))
            r2[i][j]=mean_rsquareds
        j=j+1
    rsquared_df = pd.DataFrame(data=r2[i], index=studies, columns=list_of_arg_dicts).T
    rsquared_df.to_csv(f'Path where you want to save the outputs/{model_name}_all_studies.csv', float_format='%.2f')
    i=i+1

################################## Figure S2 ##################################
model_name_to_full_name_dict = {'knn': 'k-Nearest Neighbors',
                                'ridge': 'Ridge',
                                'lasso': 'Lasso',
                                'svr - poly kernel':    'Support Vector Regression - Polynomial kernel',
                                'svr - rbf kernel':     'Support Vector Regression - Radial basis function kernel',
                                'svr - sigmoid kernel': 'Support Vector Regression - Sigmoid kernel'}
def heatmap_model_results(path):
    model_files = [x for x in os.listdir(path) if x.endswith('_all_studies.csv')]
    
    out_folder = 'Path where you want to save the figures/' 
    
    if not os.path.exists(out_folder):
        os.makedirs(out_folder)
    
    for model_file in model_files:
        if 'ols' in model_file: # don't bother with OLS results since they weren't pre-reg'd and are very inaccurate
            continue
            
        plt.subplots(figsize=(14,12));
        model_results = pd.read_csv(path+model_file, index_col=0)
        model_results['average'] = model_results.mean(axis='columns')
        model_results = model_results.loc[:,['average']+list(model_results.columns[:-1])]
        
        # simplify x-ticks...
        new_indices = []
        for hyper_dict_as_str in model_results.index:
            hyper_dict = literal_eval(hyper_dict_as_str)
            hyper_dict.pop('kernel', None)
            new_index = list(hyper_dict.values())[0]
            new_indices.append(new_index)

        model_results.index = new_indices
        hyperparameter = list(hyper_dict.keys())[0]
        ax = sns.heatmap(model_results.T, vmin=0, vmax=1, annot=True, cmap="Blues", cbar_kws={'label': 'Out-of-Sample $\it{r^2}$'}, annot_kws={"size": 15})
        ax.tick_params(labelsize=15)
        cbar_axes = ax.figure.axes[-1]
        cbar_axes.yaxis.label.set_size(18)
        cbar_axes.tick_params(labelsize=15)

        if hyperparameter == 'alpha':
            hyperparameter = 'λ'
        if hyperparameter == 'n_neighbors':
            hyperparameter = 'k'
        
        plt.yticks(rotation=0) 
        plt.xlabel(hyperparameter, rotation='horizontal', fontsize=14)
        plt.ylabel('Study', rotation='vertical', fontsize=14)
        
        output_file_name = model_file[:-4]
        model_name = output_file_name.split('_')[0]
        
        string_labels = []
        for i in range(0,10):
            string_labels.append(r'$10^{%01d}$' % (i-2))

        if model_name != 'knn':
            plt.xticks(ticks=np.arange(0.5,10.5), labels=string_labels, rotation='horizontal');

        if model_name == 'svr':
            possible_kernel = output_file_name.split('_')[1]
            model_name += ' - ' + possible_kernel + ' kernel'
        
        model_name = model_name_to_full_name_dict[model_name]
        
        plt.title(model_name, fontsize=20)
        plt.savefig(out_folder + f'{output_file_name}.png')
        plt.show()
        
word2vec_r2_path = 'Path where you save {model_name}_all_studies.csv on line 110'
heatmap_model_results(word2vec_r2_path)

###############################################################################
###################### III. Group level model comparison ######################
###############################################################################

################ 1. Vector Representation Model ##################
dict_of_vrm_pred={}
for study in studies:
    X = dict_of_Xs['word2vec'].values
    y = dict_of_ys[study].values
    y_pred = np.zeros(shape=len(y))
    for train_index, test_index in LeaveOneOut().split(X):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]
        y_pred[test_index] = Ridge(alpha=1).fit(X_train,y_train).predict(X_test)
    dict_of_vrm_pred[study] = y_pred

################ 2. Nutrient Content Model ##################    
dict_of_nm_pred={}
for study in studies:
    X = dict_of_Xs['nutrient'].values
    y = dict_of_ys[study].values
    y_pred = np.zeros(shape=len(y))
    for train_index, test_index in LeaveOneOut().split(X):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]
        y_pred[test_index] = LinearRegression().fit(X_train, y_train).predict(X_test)
    dict_of_nm_pred[study] = y_pred
    
################ 3. Combined Model ##################
dict_of_cm_pred={}
for study in studies:
    X = dict_of_Xs['combined'].values
    y = dict_of_ys[study].values
    y_pred = np.zeros(shape=len(y))
    for train_index, test_index in LeaveOneOut().split(X):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]
        y_pred[test_index] = Ridge(alpha=1).fit(X_train,y_train).predict(X_test)
    dict_of_cm_pred[study] = y_pred
   
################################## Table S6 ###################################
def se(r2,k):
    return ((4*r2*(1-r2)**2*(172-k-1)**2)/((172**2-1)*175))**0.5
comparison=pd.DataFrame(columns=studies, 
                   index=['VRM-r','NM-r','CM-r','VRM','VRM-L','VRM-U','NM','NM-L','NM-U','CM','CM-L','CM-U',
                          'VRM-MSE','NM-MSE','CM-MSE'])        
for study in studies:
    y=dict_of_ys[study].values
    y_pred_vrm=dict_of_vrm_pred[study]
    y_pred_nm=dict_of_nm_pred[study]
    y_pred_cm=dict_of_cm_pred[study]
    
    vrm_r=pearsonr(y,y_pred_vrm)[0]
    nm_r=pearsonr(y,y_pred_nm)[0]
    cm_r=pearsonr(y,y_pred_cm)[0]
    
    vrm=float(r2_score(y,y_pred_vrm))
    vrm_l=vrm-2*se(vrm,300)
    vrm_u=vrm+2*se(vrm,300)
    nm=float(r2_score(y,y_pred_nm))
    nm_l=nm-2*se(nm,11)
    nm_u=nm+2*se(nm,11)
    cm=float(r2_score(y,y_pred_cm))
    cm_l=cm-2*se(cm,311)
    cm_u=cm+2*se(cm,311)

    vrm_mse=np.mean((y_pred_vrm-y)**2)
    nm_mse=np.mean((y_pred_nm-y)**2)
    cm_mse=np.mean((y_pred_cm-y)**2)
    
    comparison[study]=[vrm_r,nm_r,cm_r,vrm,vrm_l,vrm_u,nm,nm_l,nm_u,cm,cm_l,cm_u,vrm_mse,nm_mse,cm_mse]
comparison.T.to_csv('Path where you want to store the outputs/name of the output file.csv')

################################## Figure S3 ##################################
models = ['NM', 'VRM', 'CM']
studies = ('1A', '1B', '1C', '2A_control', '2A_treatment', '2B_control', '2B_treatment', '2C_control', '2C_treatment')
pos = np.arange(len(studies))
bar_width = 0.3
comparison=comparison.T

plt.figure(figsize=(20,14)) 
plt.bar(pos,comparison['NM'].values,bar_width,color='black',edgecolor='black', alpha=0.7)
plt.bar(pos+bar_width,comparison['VRM'].values,bar_width,color='grey',edgecolor='grey', alpha=1)
plt.bar(pos+2*bar_width,comparison['CM'].values,bar_width,color='grey',edgecolor='grey', alpha=0.7)
plt.errorbar(pos, comparison['NM'].values, yerr=comparison['NM-U'].values-comparison['NM'].values, fmt='none', ecolor='black', capsize=5, capthick=2)
plt.errorbar(pos+bar_width, comparison['VRM'].values, yerr=comparison['VRM-U'].values-comparison['VRM'].values, fmt='none', ecolor='black', capsize=5, capthick=2)
plt.errorbar(pos+2*bar_width, comparison['CM'].values, yerr=comparison['CM-U'].values-comparison['CM'].values, fmt='none', ecolor='black', capsize=5, capthick=2)
plt.xticks(pos+0.32, studies, fontsize=22, rotation=45)
plt.yticks(fontsize=22)
plt.xlabel('Study', fontsize=22)
plt.ylabel('Out-of-Sample $\it{r^2}$', fontsize=22)
plt.legend(models, fontsize=22)
plt.savefig('Path where you want to save the figure\name of the figure.png') 
plt.show()
        
###############################################################################
####################### IV. Individual level model fits #######################
###############################################################################

################ 1. Vector Representation Model ##################

dict_of_individual_y_pred_VRM = dict()
dict_of_individual_corr_VRM = dict()
for study in studies:
    X = dict_of_Xs['word2vec'].values
    all_individual_preds = np.zeros(shape=dict_of_individual_ys[study].shape)
    all_individual_corr = np.zeros(len(dict_of_individual_ys[study]))
    for individual_idx, y in enumerate(dict_of_individual_ys[study].values):
        y_pred = np.zeros(shape=len(y))
        for train_index, test_index in LeaveOneOut().split(X):
            X_train, X_test = X[train_index], X[test_index]
            y_train = y[train_index].astype(float)
            y_notna_idxs = ~np.isnan(y_train)
            y_train = y_train[y_notna_idxs]
            X_train = X_train[y_notna_idxs]
            y_pred[test_index] = Ridge(alpha=1).fit(X_train,y_train).predict(X_test)
        all_individual_preds[individual_idx] = y_pred
        nas = ~np.isnan(y)
        all_individual_corr[individual_idx] = r2_score(y[nas],y_pred[nas])
    individual_predictions = pd.DataFrame(all_individual_preds, columns=dict_of_individual_ys[study].columns)
    dict_of_individual_y_pred_VRM[study] = individual_predictions  
    dict_of_individual_corr_VRM[study] = all_individual_corr

################ 2. Nutrient Model ################

dict_of_individual_y_pred_NM = dict()
dict_of_individual_corr_NM = dict()
for study in studies:
    X = dict_of_Xs['nutrient'].values
    all_individual_preds = np.zeros(shape=dict_of_individual_ys[study].shape)
    all_individual_corr = np.zeros(len(dict_of_individual_ys[study]))
    for individual_idx, y in enumerate(dict_of_individual_ys[study].values):
        y_pred = np.zeros(shape=len(y))
        for train_index, test_index in LeaveOneOut().split(X):
            X_train, X_test = X[train_index], X[test_index]
            y_train = y[train_index].astype(float)
            y_notna_idxs = ~np.isnan(y_train)
            y_train = y_train[y_notna_idxs]
            X_train = X_train[y_notna_idxs]
            y_pred[test_index] = LinearRegression().fit(X_train, y_train).predict(X_test)
        all_individual_preds[individual_idx] = y_pred
        nas = ~np.isnan(y)
        all_individual_corr[individual_idx] = r2_score(y[nas],y_pred[nas])
    individual_predictions = pd.DataFrame(all_individual_preds, columns=dict_of_individual_ys[study].columns)
    dict_of_individual_y_pred_NM[study] = individual_predictions  
    dict_of_individual_corr_NM[study] = all_individual_corr

################ 3. Combined Model ##################

dict_of_individual_y_pred_CM = dict()
dict_of_individual_corr_CM = dict()
for study in studies:
    X = dict_of_Xs['combined'].values
    all_individual_preds = np.zeros(shape=dict_of_individual_ys[study].shape)
    all_individual_corr = np.zeros(len(dict_of_individual_ys[study]))
    for individual_idx, y in enumerate(dict_of_individual_ys[study].values):
        y_pred = np.zeros(shape=len(y))
        for train_index, test_index in LeaveOneOut().split(X):
            X_train, X_test = X[train_index], X[test_index]
            y_train = y[train_index].astype(float)
            y_notna_idxs = ~np.isnan(y_train)
            y_train = y_train[y_notna_idxs]
            X_train = X_train[y_notna_idxs]
            y_pred[test_index] = Ridge(alpha=1).fit(X_train,y_train).predict(X_test)
        all_individual_preds[individual_idx] = y_pred
        nas = ~np.isnan(y)
        all_individual_corr[individual_idx] = r2_score(y[nas],y_pred[nas])
    individual_predictions = pd.DataFrame(all_individual_preds, columns=dict_of_individual_ys[study].columns)
    dict_of_individual_y_pred_CM[study] = individual_predictions  
    dict_of_individual_corr_CM[study] = all_individual_corr

individual_summary=pd.DataFrame(columns=studies, 
                                index=['VRM-mean','VRM-se','NM-mean','NM-se',
                                         'CM-mean','CM-se','t12','p12','t13','p13',
                                         't23','p23'])
for study in studies:
    corr_vrm=dict_of_individual_corr_VRM[study][~np.isnan(dict_of_individual_corr_VRM[study])]
    corr_nm=dict_of_individual_corr_NM[study][~np.isnan(dict_of_individual_corr_NM[study])]
    corr_cm=dict_of_individual_corr_CM[study][~np.isnan(dict_of_individual_corr_CM[study])]
    vrm_mean=np.mean(corr_vrm)
    vrm_se=np.std(corr_vrm)/(len(corr_vrm)**0.5)
    t12, p12 = stats.ttest_rel(corr_vrm,corr_nm)
    nm_mean=np.mean(corr_nm)
    nm_se=np.std(corr_nm)/(len(corr_nm)**0.5)
    t13, p13 = stats.ttest_rel(corr_vrm,corr_cm)
    cm_mean=np.mean(corr_cm)
    cm_se=np.std(corr_cm)/(len(corr_cm)**0.5)
    t23, p23 = stats.ttest_rel(corr_nm,corr_cm)
    individual_summary[study]=[vrm_mean,vrm_se,nm_mean,nm_se,cm_mean,cm_se,
                      t12,p12,t13,p13,t23,p23]
individual_summary.T.to_csv('Path where you want to store the outputs/name of the output file.csv')

################################## Figure S4 ##################################
models = ['NM', 'VRM', 'CM']
studies = ('1A', '1B', '1C', '2A_control', '2A_treatment', '2B_control', '2B_treatment', '2C_control', '2C_treatment')
pos = np.arange(len(studies))
bar_width = 0.3
individual_summary=pd.read_csv('outputs\individual fits rsquareds.csv')

plt.figure(figsize=(20,12)) 
plt.bar(pos,individual_summary.T['NM-mean'].values,bar_width,color='black',edgecolor='black', alpha=0.7)
plt.bar(pos+bar_width,individual_summary.T['VRM-mean'].values,bar_width,color='grey',edgecolor='grey', alpha=1)
plt.bar(pos+2*bar_width,individual_summary.T['CM-mean'].values,bar_width,color='grey',edgecolor='grey', alpha=0.7)
plt.errorbar(pos, individual_summary.T['NM-mean'].values, yerr=individual_summary.T['VRM-se'].values, fmt='none', ecolor='black', capsize=5, capthick=2)
plt.errorbar(pos+bar_width, individual_summary.T['VRM-mean'].values, yerr=individual_summary.T['NM-se'].values, fmt='none', ecolor='black', capsize=5, capthick=2)
plt.errorbar(pos+2*bar_width, individual_summary.T['CM-mean'].values, yerr=individual_summary.T['CM-se'].values, fmt='none', ecolor='black', capsize=5, capthick=2)
plt.xticks(pos+0.32, studies, fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel('Study', fontsize=22)
plt.ylabel('Out-of-Sample $\it{r^2}$', fontsize=22)
plt.legend(models, fontsize=22)
plt.savefig('where you want to save the figure\name of the figure.png') 
plt.show()

