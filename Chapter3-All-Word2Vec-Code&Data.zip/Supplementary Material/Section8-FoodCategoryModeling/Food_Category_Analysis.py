# -*- coding: utf-8 -*-
"""

Paper: "Computational Methods for Predicting and Understanding Food Judgment"

Section 8 of the Supplementary Materials

Outline:
    
[I] Predicted Healthiness Ratings by Food Category
    - Vector Representation Model
    - Nutrient Model
    - Combined Model



"""

import pandas as pd
import pickle
import numpy as np
from sklearn.model_selection import LeaveOneOut
from sklearn.linear_model import Ridge, LinearRegression
import scipy.stats as stats
from sklearn.metrics import r2_score
from math import sqrt
from scipy.stats import pearsonr


###############################################################
################ Vector Representation Model ##################
###############################################################


### read in csv files for the vector representation model
control_VRM_1A=pd.read_csv(r'Path where the CSV file is stored/food_cat_vrm_1A.csv')
exp_VRM_1B=pd.read_csv(r'Path where the CSV file is stored/food_cat_vrm_1B.csv')
exp_VRM_1C=pd.read_csv(r'Path where the CSV file is stored/food_cat_vrm_1C.csv')

control_VRM_2A=pd.read_csv(r'Path where the CSV file is stored/food_cat_vrm_2A_con.csv')
exp_VRM_2A=pd.read_csv(r'Path where the CSV file is stored/food_cat_vrm_2A_exp.csv')

control_VRM_2B=pd.read_csv(r'Path where the CSV file is stored/food_cat_vrm_2B_con.csv')
exp_VRM_2B=pd.read_csv(r'Path where the CSV file is stored/food_cat_vrm_2B_exp.csv')

control_VRM_2C=pd.read_csv(r'Path where the CSV file is stored/food_cat_vrm_2C_con.csv')
exp_VRM_2C=pd.read_csv(r'Path where the CSV file is stored/food_cat_vrm_2C_exp.csv')


#replace "control_VRM_1A" in x and y with variable name for the given condition
y = control_VRM_1A['actual_mean']  
x = control_VRM_1A['predicted_mean']


pearsonr(y,x)  
r2_score(y,x) 

'''
VRM: r-value

1A (0.9334858671331325, 1.898052078971556e-09)
1B (0.9207978160564068, 8.714831316906149e-09)
1C (0.9131007240092359, 1.9512141799633458e-08)
2A_con (0.9266050250978495, 4.487441552919791e-09)
2A_exp (0.9181197105778698, 1.1638754456021615e-08)
2B_con (0.93337514222806, 1.925889313430246e-09)
2B_exp (0.9066143060303129, 3.6403756623436e-08)
2C_con (0.9312049477302143, 2.5493414162248986e-09)
2C_exp (0.8843950605661162, 2.2860918476516688e-07)

VRM: r2

1A 0.8277886273465112
1B 0.7818089672187765
1C 0.7979976177646853
2A_con 0.8022202865044845
2A_exp 0.7946569150271354
2B_con 0.8230364575792608
2B_exp 0.7625133971639821
2C_con 0.820824028394101
2C_exp 0.6781381755642065

'''

##########################################################
################ Nutrient Content Model ##################
##########################################################


### read in csv files for the nutrient model
control_NM_1A=pd.read_csv(r'Path where the CSV file is stored/food_cat_nm_1A.csv')
exp_NM_1B=pd.read_csv(r'Path where the CSV file is stored/food_cat_nm_1B.csv')
exp_NM_1C=pd.read_csv(r'Path where the CSV file is stored/food_cat_nm_1C.csv')

control_NM_2A=pd.read_csv(r'Path where the CSV file is stored/food_cat_nm_2A_con.csv')
exp_NM_2A=pd.read_csv(r'Path where the CSV file is stored/food_cat_nm_2A_exp.csv')

control_NM_2B=pd.read_csv(r'Path where the CSV file is stored/ood_cat_nm_2B_con.csv')
exp_NM_2B=pd.read_csv(r'Path where the CSV file is stored/food_cat_nm_2B_exp.csv')

control_NM_2C=pd.read_csv(r'Path where the CSV file is stored/food_cat_nm_2C_con.csv')
exp_NM_2C=pd.read_csv(r'Path where the CSV file is stored/food_cat_nm_2C_exp.csv')


y = control_NM_1A['actual_mean']  
x = control_NM_1A['predicted_mean']


pearsonr(y,x)  
r2_score(y,x) 
 
 
'''
NM: r-value

1A (0.5610110334633147, 0.010068700903877993)
1B (0.5867304304385821, 0.00654039788974236)
1C  (0.5509600745675326, 0.01181130653184978)
2A_con (0.5333434924411664, 0.015449386842664874)
2A_exp (0.6629904164056926, 0.0014422482919996843)
2B_con (0.5312229497358728, 0.01594208253701912)
2B_exp (0.7402931323417201, 0.00018981721911062022)
2C_con (0.5721989237754479, 0.008380815517474802)
2C_exp (0.8919009549294066, 1.2853166088563863e-07)

NM: r2

1A 0.3051191152270426
1B 0.3423178232006353
1C 0.28528629394329996  
2A_con 0.27801257320654427
2A_exp 0.43845920172766195
2B_con 0.2694251581722532
2B_exp 0.5475764688003724
2C_con 0.32098262499084507
2C_exp 0.7927972844913058
 
'''
 
##################################################
################ Combined Model ##################
##################################################


### read in csv files for the combined model 
control_CM_1A=pd.read_csv(r'Path where the CSV file is stored/food_cat_cm_1A.csv')
exp_CM_1B=pd.read_csv(r'Path where the CSV file is stored/food_cat_cm_1B.csv')
exp_CM_1C=pd.read_csv(r'Path where the CSV file is stored/food_cat_cm_1C.csv')

control_CM_2A=pd.read_csv(r'Path where the CSV file is stored/ood_cat_cm_2A_con.csv')
exp_CM_2A=pd.read_csv(r'Path where the CSV file is stored/food_cat_cm_2A_exp.csv')

control_CM_2B=pd.read_csv(r'Path where the CSV file is stored/food_cat_cm_2B_con.csv')
exp_CM_2B=pd.read_csv(r'Path where the CSV file is stored/food_cat_cm_2B_exp.csv')

control_CM_2C=pd.read_csv(r'Path where the CSV file is stored/food_cat_cm_2C_con.csv')
exp_CM_2C=pd.read_csv(r'Path where the CSV file is stored//food_cat_cm_2C_exp.csv')



y = control_CM_1A['actual_mean']  
x = control_CM_1A['predicted_mean']


pearsonr(y,x)  
r2_score(y,x) 
 
 
'''
CM: r-value

1A (0.9257179450767945, 4.983404420502581e-09)
1B (0.9170630895694207, 1.301104531118822e-08)
1C (0.9037663776026885, 4.719859881738974e-08)
2A_con (0.9171050365030328, 1.2953965655197223e-08)
2A_exp (0.9314615095945034, 2.467384921151015e-09)
2B_con (0.9199675791628559, 9.542795292802595e-09)
2B_exp (0.9450760659005324, 3.536134869508041e-10)
2C_con (0.9248158397665065, 5.536718107638342e-09)
2C_exp (0.9775420600701312, 1.272320007118079e-13)

CM: r2

1A 0.8404944706352224
1B 0.8236466630441627
1C 0.8080413055879422
2A_con 0.815625611582399
2A_exp 0.8575210640026647
2B_con 0.8269978156897604
2B_exp 0.8838601149427675
2C_con 0.8388277493491479
2C_exp 0.9510048335944126
 
'''


