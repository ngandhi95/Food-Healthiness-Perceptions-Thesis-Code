
-------------------
  
##  Summary of Preprocessing Steps carried out in "2. Superfoods-Preprocessing.R"

#a. uses raw nowcorpus articles from "Superfoods-Import-NowCorpus.Rmd"
#1. standardize to lower-case 
#2. remove duplicates (based on same title and news outlet) 
#3. convert all character encoding to ASCII, which strips accents 
#4. remove duplicates (based on same article ID) 
#5. winsorize on word count (.999)
#6. filter only food related articles (based on food name vocab) 
#7. remove HTML tags 
#8. remove URLs 
#9. replace various superfood spellings with consistent token 
#10. parse texts by article ID: POS tagging, lemmatization 
#11. filter only "ACCEPTED_TAGS" 
#12. remove stop words 
#13. for words like "would've" remove "ve" as lack of apostrophe causes lemmatization errors
#14. find food name compounds (from food name vocab) and replace spaces with hyphens (e.g. coconut oil) 
#15. output clean data into files of equal size. 


#TOTAL ARTICLE NO: 547,568

-------------------

##setup - install packages

library(data.table)
library(qdapRegex)
library(quanteda)
library(parallel)
library(doParallel)
library(stringr)
library(reticulate)
library(spacyr)
use_condaenv("nlp")
-------------------

##################################################################
##                             READ                             ##
##################################################################

# read food names:
food_names <- scan('../FoodNameVocabulary/Food_Name_Vocabulary.csv', 
                   character(1), sep = ",", skip = 1, quiet = TRUE)
food_names <- iconv(food_names, from = "latin1", to = "UTF-8")

# read all food-related articles:
files <- list.files('../4.RawFoodRelatedArticles/', 
                    full.names = TRUE, pattern = "*.tsv") # list all files
full_dt <- rbindlist(lapply(files, fread, sep = '\t')) # read full data



##################################################################
##                         SELECT CASES                         ##
##################################################################

# drop duplicate articles with the same title and outlet
full_dt[, `:=`(title = tolower(title), news_outlet = tolower(news_outlet))]
full_dt <- unique(full_dt, by = c("title", "news_outlet"))
full_dt[, text := iconv(text, from = "latin1", to = "UTF-8")]
full_dt[, text := iconv(text, from = "UTF-8", to = "ASCII//TRANSLIT")] # strip accents
full_dt <- full_dt[!duplicated(id), ] 

# winsorize on word count
full_dt <- full_dt[word_count < quantile(word_count, .99), ]

# keep only articles mentioning at least one food name
# this is a very long step, as the regular expression is huuuuuge
food_re <- paste0("\\b", str_replace_all(food_names, "_", " "), "\\b", 
                  collapse = "|")
full_dt[, has_food := grepl(food_re, text, ignore.case = TRUE)]
full_dt <- full_dt[(has_food), ]
full_dt$has_food <- NULL



##################################################################
##                          PREPROCESS                          ##
##################################################################

# remove HTML tags and URLs:
full_dt[, text := gsub("<[a-z]+>", "", text, ignore.case = TRUE)] # remove html tags
full_dt[, text := rm_url(text)] # remove URLs

# replace all "superfood" mentions with consistent token
re_sf <- regex("super\\s*?-?\\s*?food", ignore_case = TRUE)
full_dt[, text := str_replace_all(text, re_sf, "superfood")]


# lemmatize:
# using own spaCy implementation since spacyr has significantly more overhead and no parallelism support
# this takes a while...
lemmatize <- import("lemmatize")$lemmatize_parallel
accepted_tags = c("NOUN", "PROPN", "ADJ", "ADV", "VERB",
                  "PART", "ADP", "SCONJ", "CCONJ")
full_dt[, text := lemmatize(text, "en_core_web_md", stoplist = stopwords(), 
                            filter_tags = accepted_tags, batch_size = 200L, n_jobs = 3L)]
dt[, text := gsub("\\bve\\b", "", text)] # replace "'ve" leftover (no apostrophe led to lemmatization errors)
# replace compound food names (coconut oil -> coconut_oil, etc.):
coll <- grep("_", food_names, value = TRUE)
coll <- strsplit(coll, "_")
toks <- tokens(full_dt$text)
toks <- tokens_compound(toks, coll, concatenator = "_")
toks <- vapply(toks, function(x) paste(as.character(x), collapse = " "), character(1))
full_dt[, text := toks]


##################################################################
##                            EXPORT                            ##
##################################################################


# write to files (chunk into 10000 rows each file so that it fits github)
chunk_size <- 10000
n_chunks <- nrow(full_dt) %/% chunk_size + 1
for (i in 1 : n_chunks) {
  lwr <- (i - 1) * chunk_size + 1
  upr <- min(lwr + chunk_size - 1, nrow(full_dt))
  path <- file.path("../outputs/clean/", paste0("clean", i, ".tsv"))
  fwrite(full_dt[lwr:upr, ], path, sep = '\t')
}





