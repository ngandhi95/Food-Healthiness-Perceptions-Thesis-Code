# -*- coding: utf-8 -*-
"""

Computational Analyses for Study 3 in the Further Reflections Chapter of my PhD thesis entitled "Understanding individual food healthiness perceptions using a computational approach."
(control vs the non-nutrient-based labels: "organic", "superfood" and "fairtrade") 

    
"""
    
'''load packages '''

import csv
import numpy as np
import gensim.models as models
import pandas as pd
from scipy.stats.stats import pearsonr
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import Normalizer
from sklearn.model_selection import LeaveOneOut
from pattern.text.en import singularize
from sklearn.metrics import r2_score


# download, save and read in Word2Vec [will take approx 10 minutes]
word2vec = models.KeyedVectors.load_word2vec_format(r'Insert file path/GoogleNews-vectors-negative300.bin.gz', binary=True)


#######################################################################################
################################### 1. Data Cleaning ##################################
#######################################################################################


'''load data for each study and split into control and experimental condition'''

ppt_ratings = pd.read_csv(r'Insert file path/food_labelling_ppt_data.csv')
no_label =ppt_ratings[ppt_ratings['condition']=='control']
sf =ppt_ratings[ppt_ratings['condition']=='superfood']
ft =ppt_ratings[ppt_ratings['condition']=='fairtrade']
org =ppt_ratings[ppt_ratings['condition']=='organic']



'''generate group level data for each condition'''
no_label =no_label.groupby(['food_name']).mean()
sf =sf.groupby(['food_name']).mean()
ft =ft.groupby(['food_name']).mean()
org =org.groupby(['food_name']).mean()




##################################################################
################ 2. Vector Representation Model ##################
##################################################################


'''get word vectors for food items (x in model)'''
food=no_label.index.values
x=word2vec[food[0]]
for item in food[1:len(food)]:
    x=np.vstack((x,word2vec[item]))
'''normalize word vectors'''
nx=Normalizer().fit(x).transform(x)



'''Leave-one-out cross-validation (LOOCV) for Vector Representation Model'''

'''change y to switch condition'''
#y=no_label['rating']    #looy_ridge_no_label_VRM
#y=sf['rating']          #looy_ridge_sf_VRM
#y=ft['rating']          #looy_ridge_ft_VRM
y=org['rating']         #looy_ridge_org_VRM



'''replace "looy_ridge_[]" with the corresponding variable name for the condition '''
looy_ridge_org_VRM=np.zeros(168)  #change condition accordingly
for train_index, test_index in LeaveOneOut().split(nx):
    X_train, X_test = nx[train_index], nx[test_index]
    y_train, y_test = y[train_index], y[test_index]
    looy_ridge_org_VRM[test_index]=Ridge(alpha=1).fit(X_train,y_train).predict(X_test)    #change condition accordingly
    
    
    

    
'''remove # to calculate the correlation coefficient for that condition (and check it against these previously calculated & reported coefficients)''' 

'''pearsonr'''
#loocv_no_label_VRM=pearsonr(y,looy_ridge_no_label_VRM)   # (0.8583655451572704, 5.515005928910682e-50) for No Label condition 
#loocv_sf_VRM=pearsonr(y,looy_ridge_sf_VRM)               # (0.8672679239593855, 3.7100557353977246e-52) for Superfood Condition 
#loocv_ft_VRM=pearsonr(y,looy_ridge_ft_VRM)               # (0.8542531031755649, 4.959805987203439e-49) for Fairtrade Condition 
#loocv_org_VRM=pearsonr(y,looy_ridge_org_VRM)             # (0.8616517835922072, 9.065362775884089e-51) for Organic Condition 

''' r2 '''
#loocv_no_label_VRM=r2_score(y,looy_ridge_no_label_VRM)   # 0.7193458151610215 for No Label condition (Upper Bound CI = 0.7758367091934507; Lower Bound CI = 0.6628549211285922)
#loocv_sf_VRM=r2_score(y,looy_ridge_sf_VRM)               # 0.7341514478044854 for Superfood Condition (Upper Bound CI = 0.7882100975916941; Lower Bound CI = 0.6800927980172766)
#loocv_ft_VRM=r2_score(y,looy_ridge_ft_VRM)               # 0.7132360787855708 for Fairtrade Condition (Upper Bound CI = 0.7707111114892908; Lower Bound CI = 0.6557610460818508)
loocv_org_VRM=r2_score(y,looy_ridge_org_VRM)             # 0.7246257357900436 for Organic Condition (Upper Bound CI = 0.7802569183417984; Lower Bound CI = 0.6689945532382888)


##confidence interval formula    
#y = y
#x =  looy_ridge_org_VRM  
#r2 = r2_score(y,x)    
#
#def se(r2,n,k):
#    return ((4*r2*(1-r2)**2*(n-k-1)**2)/((n**2-1)*(n+3)))**0.5
#
#se = se(r2, 168, 300)
#
#r2 + 1.96*se


#############################################################
################ 3. Nutrient Content Model ##################
#############################################################


'''LOOCV using calories+nutrients+TLL change y accordingly'''
nutrient=pd.read_csv(r'Insert file path/food_labelling_nutrient_info.csv')  
X = nutrient[["energy","totfat","satfat","totsug","salt","sodium","protein","totfatc","satfatc","totsugc","saltc"]]
X=X.values

'''change y to switch condition'''
#y=no_label['rating']    #looy_linear_no_label_NM
#y=sf['rating']          #looy_linear_sf_NM
#y=ft['rating']          #looy_linear_ft_NM
y=org['rating']         #looy_linear_org_NM




'''replace "looy_linear[]" with the corresponding variable name for the condition '''
looy_linear_org_NM=np.zeros(168)  #change condition accordingly #for some reason was 139
for train_index, test_index in LeaveOneOut().split(X):
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]
    looy_linear_org_NM[test_index]=LinearRegression().fit(X_train, y_train).predict(X_test)   #change condition accordingly
    
'''remove # to calculate the correlation coefficient for that condition (and check it against these previously calculated & reported coefficients)'''    

'''pearsonr'''    
#loocv_linear_no_label_NM=pearsonr(y,looy_linear_no_label_NM)     # (0.574782865077887, 3.7208769699567133e-16) for No Label condition  
#loocv_linear_sf_NM=pearsonr(y,looy_linear_sf_NM)     # (0.5795450023053597, 1.8623021967311081e-16) for Superfood Condition
#loocv_linear_ft_NM=pearsonr(y,looy_linear_ft_NM)     # (0.5802766052667644, 1.6727694632690865e-16) for Fairtrade Condition
#loocv_linear_org_NM=pearsonr(y,looy_linear_org_NM)     # (0.5641406339515151, 1.679237902008755e-15) for Organic Condition


''' r2 '''
#loocv_linear_no_label_NM=r2_score(y,looy_linear_no_label_NM)     # 0.323343091236882 for No Label condition  (Upper Bound CI = 0.43044848338970326; Lower Bound CI = 0.2162376990840607)  
#loocv_linear_sf_NM=r2_score(y,looy_linear_sf_NM)     # 0.3289645094564283 for Superfood Condition  (Upper Bound CI = 0.4360994260255153; Lower Bound CI = 0.22182959288734128)  
#loocv_linear_ft_NM=r2_score(y,looy_linear_ft_NM)   # 0.3295349838343222 for Fairtrade Condition  (Upper Bound CI = 0.43667159560714286; Lower Bound CI = 0.2223983720615016)  
loocv_linear_org_NM=r2_score(y,looy_linear_org_NM)     # 0.3107094158534056 for Organic Condition  (Upper Bound CI = 0.41766182594552; Lower Bound CI = 0.20375700576129124)  


##confidence interval formula    
#y = y
#x =  looy_linear_org_NM  
#r2 = r2_score(y,x)
#
#def se(r2,n,k):
#    return ((4*r2*(1-r2)**2*(n-k-1)**2)/((n**2-1)*(n+3)))**0.5
#
#se = se(r2, 168, 11)
#
#r2 + 1.96*se






#####################################################
################ 4. Combined Model ##################
#####################################################


'''LOOCV using combined Vector Representation and Nutrient Model predictors'''
combination = np.hstack((nx,X))
    

'''change y to switch condition'''
#y=no_label['rating']    #looy_ridge_no_label_CM
#y=sf['rating']          #looy_ridge_sf_CM
#y=ft['rating']          #looy_ridge_ft_CM
y=org['rating']         #looy_ridge_org_CM


    
    
'''replace "looy_ridge_[]" with the corresponding variable name for the condition '''
looy_ridge_org_CM=np.zeros(168)   #change condition accordingly
for train_index, test_index in LeaveOneOut().split(combination):
    X_train, X_test = combination[train_index], combination[test_index]
    y_train, y_test = y[train_index], y[test_index]
    looy_ridge_org_CM[test_index]=Ridge(alpha=1).fit(X_train,y_train).predict(X_test)     #change condition accordingly
 
'''remove # to calculate the correlation coefficient for that condition (and check it against these previously calculated & reported coefficients)'''      

'''pearsonr'''
#loocv_no_label_CM=pearsonr(y,looy_ridge_no_label_CM)   # (0.8544468153665926, 4.479114457469285e-49) for No Label condition
#loocv_sf_CM=pearsonr(y,looy_ridge_sf_CM)               # (0.8614899167570079, 9.919292991701882e-51) for Superfood Condition
#loocv_ft_CM=pearsonr(y,looy_ridge_ft_CM)               # (0.8486536982090938, 8.875139196564431e-48) for Fairtrade Condition
#loocv_org_CM=pearsonr(y,looy_ridge_org_CM)             # (0.8560721140673164, 1.893158803303723e-49) for Organic Condition

''' r2 '''
#loocv_no_label_CM=r2_score(y,looy_ridge_no_label_CM)   # 0.727257690913022 for No Label condition  (Upper Bound CI = 0.78702250741173; Lower Bound CI = 0.6674928744143139)  
#loocv_sf_CM=r2_score(y,looy_ridge_sf_CM)               # 0.7392814195285551 for Superfood Condition  (Upper Bound CI = 0.7968818586723403; Lower Bound CI = 0.6816809803847699)  
#loocv_ft_CM=r2_score(y,looy_ridge_ft_CM)               # 0.7182289036646573 for Fairtrade Condition  (Upper Bound CI = 0.7795876951232096; Lower Bound CI = 0.656870112206105)  
loocv_org_CM=r2_score(y,looy_ridge_org_CM)             # 0.7298848377960568 for Organic Condition (Upper Bound CI = 0.789180790313797; Lower Bound CI = 0.6705888852783167)  


##confidence interval formula    
y = y
x =  looy_ridge_org_CM  
r2 = r2_score(y,x)    

def se(r2,n,k):
    return ((4*r2*(1-r2)**2*(n-k-1)**2)/((n**2-1)*(n+3)))**0.5

se = se(r2, 168, 311)

r2 + 1.96*se




###################################################################################
################# 5. Differences Between Conditions of Each Study #################
###################################################################################


    
'''Predicting Differences Between Conditions of Each Study using the Vector Representation Model '''

'''change y to switch condition'''
#y=sf['rating']-no_label['rating']       #looy_ridge_diff_sf_VRM
#y=ft['rating']-no_label['rating']      #looy_ridge_diff_ft_VRM
y=org['rating']-no_label['rating']      #looy_ridge_diff_org_VRM


'''replace "looy_ridge_[]" with the corresponding variable name for the condition '''
looy_ridge_diff_org_VRM=np.zeros(168)     #change condition accordingly
for train_index, test_index in LeaveOneOut().split(nx):
   X_train, X_test = nx[train_index], nx[test_index]
   y_train, y_test = y[train_index], y[test_index]
   looy_ridge_diff_org_VRM[test_index]=Ridge(alpha=1).fit(X_train,y_train).predict(X_test)    #change condition accordingly


'''remove # to calculate the correlation coefficient for that condition (and check it against these previously calculated & reported coefficients)''' 

'''pearsonr'''
#loocv_ridge_diff_sf_VRM=pearsonr(y,looy_ridge_diff_sf_VRM)   # (-0.11150670641983385, 0.15015250212107986) for superfood - no label condition 
#loocv_ridge_diff_ft_VRM=pearsonr(y,looy_ridge_diff_ft_VRM)   # (-0.08925569131292885, 0.2499188373409791) for fairtrade - no label condition 
loocv_ridge_diff_org_VRM=pearsonr(y,looy_ridge_diff_org_VRM)   # (-0.11749618459303436, 0.1293138480658404) for organic - no label condition

''' r2 ''' 
#loocv_ridge_diff_sf_VRM=r2_score(y,looy_ridge_diff_sf_VRM)   # -0.12876657651232892 for superfood - no label condition 
#loocv_ridge_diff_ft_VRM=r2_score(y,looy_ridge_diff_ft_VRM)   # -0.10070142223828804 for fairtrade - no label condition
loocv_ridge_diff_org_VRM=r2_score(y,looy_ridge_diff_org_VRM)   # -0.11752788537042891 for organic - no label condition

        

'''Predicting Differences Between Conditions of Each Study using the Combined Model '''

'''change y to switch condition'''

'''change y to switch condition'''
#y=sf['rating']-no_label['rating']       #looy_ridge_diff_sf_CM
#y=ft['rating']-no_label['rating']      #looy_ridge_diff_ft_CM
y=org['rating']-no_label['rating']      #looy_ridge_diff_org_CM


'''replace "looy_ridge_[]" with the corresponding variable name for the condition '''
looy_ridge_diff_org_CM=np.zeros(168)  #change condition accordingly
for train_index, test_index in LeaveOneOut().split(combination):
    X_train, X_test = combination[train_index], combination[test_index]
    y_train, y_test = y[train_index], y[test_index]
    looy_ridge_diff_org_CM[test_index]=Ridge(alpha=1).fit(X_train,y_train).predict(X_test)   

'''remove # to calculate the correlation coefficient for that condition (and check it against these previously calculated & reported coefficients)''' 

'''pearsonr'''
#loocv_ridge_diff_sf_CM=pearsonr(y,looy_ridge_diff_sf_CM)   # (-0.10821314683553472, 0.1626439398398359) for superfood - no label condition 
#loocv_ridge_diff_ft_CM=pearsonr(y,looy_ridge_diff_ft_CM)   # (0.03964666172820979, 0.6098808846901306) for fairtrade - no label condition 
loocv_ridge_diff_org_CM=pearsonr(y,looy_ridge_diff_org_CM)   # (-0.0011316178983488932, 0.9883848543931755) for organic - no label condition

''' r2 ''' 
#loocv_ridge_diff_sf_CM=r2_score(y,looy_ridge_diff_sf_CM)   #  -0.19736011741685955 for superfood - no label condition 
#loocv_ridge_diff_ft_CM=r2_score(y,looy_ridge_diff_ft_CM)   # -0.09539427091954034 for fairtrade - no label condition
loocv_ridge_diff_org_CM=r2_score(y,looy_ridge_diff_org_CM)   # -0.13338982129974175 for organic - no label condition

 






#################################################################################################
############ 6. Predicting Healthiness Ratings of "other" common words (WORD CLOUDS) ############ 
#################################################################################################


''' get normalized word vectors for common words (that are not stimuli words) in COCA dictionary'''
corpus=[item.split('_') for item in food]
vocabs=[]
for item in corpus:
    vocabs=vocabs+[item[i] for i in range(0,len(item))]
vocab = [singularize(plural) for plural in vocabs] # change plurals to singulars 
with open(r'Insert file path/COCA dictionary.csv') as a:
    f=csv.reader(a,delimiter=',')
    word=[]
    for row in f:
        if row[0] in word2vec and row[0] not in vocab:
            word.append(row[0])                   
base=word2vec[word[0]]
for item in word[1:len(word)]:
    base=np.vstack((base,word2vec[item])) 
nbase=Normalizer().fit(base).transform(base)


'''predict ratings for COCA words'''
y=no_label['rating']   
#y=sf['rating']         
#y=ft['rating']          
#y=org['rating']         

'''generate table with the healthiness ratings of all COCA words '''
pseudo=pd.DataFrame(index=word,columns=['no_label','superfood', 'fairtrade', 'organic'])
pseudo['no_label']=Ridge(alpha=1).fit(nx,y).predict(nbase) #change condition accordingly


'''generate word clouds for the words with the highest/lowest healthiness ratings'''

freq={}
for i in range(len(word)):
    freq[word[i]]=-pseudo['no_label'][i] # use -pseudo[condition_name] to see words with lowest ratings, change condition accordingly
wordcloud = WordCloud(
        width=1350,height=750,
        max_words=50,background_color='white', 
        font_path = r"Insert file path/Helvetica 400.ttf",
                      relative_scaling=1, normalize_plurals=False).generate_from_frequencies(freq) 
# set max_words to the number of words in your wordcloud
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
plt.savefig(fname='no_label_condition.pdf', format = 'pdf', dpi = 300) # rename the file accordingly
plt.show()







